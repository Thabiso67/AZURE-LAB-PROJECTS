/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usingscannerlogicaloperators;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class UsingScannerLogicalOperators {

    public static void main(String[] args) {
        //using the scanner to recieve user input
        Scanner scanner = new Scanner(System.in);
        //Captures the data from the user
        System.out.print("Enter your Age:");
        int age = scanner.nextInt();
        
        //Using the AND Operator(&&)
        if(age>=18 && age<=60 ){
        System.out.println("Your age is : "+age+" YYour are not the wworking age range ");
        }
        
        
    }
}
