/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methods;

/**
 *
 * @author lab_services_student
 */
public class Methods {

    public static String getGreeting(){
        return "Hello World!";
    }
    public static void main(String[] arg) {
        
        String result = getGreeting();
        
        //Printing the result
        System.out.println("The result is: "+result);
    }
}
