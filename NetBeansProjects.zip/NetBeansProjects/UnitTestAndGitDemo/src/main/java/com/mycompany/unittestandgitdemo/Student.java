/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.unittestandgitdemo;

/**
 *
 * @author lab_services_student
 */
public class Student {
    private String name;
    private int mark;
    
    public Student(String name, int mark) {
        this.name = name;
        this.mark = mark;
        
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setMark(int mark){
        this.mark = mark;
    }
    
    public int getMark() {
        return this.mark;
    }
    
}
