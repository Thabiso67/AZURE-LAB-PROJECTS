/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.unittestandgitdemo;

/**
 *
 * @author lab_services_student
 */
public class Roster {
    private Student [] students;
    
    public void load(Student[] std) {
        students = std;
         
    }
    
    public Student[] getStudents() {
        return students;
    }
    
    public int countPassed() {
        int count = 0;
        for (Student s : students) {
            if (s.getMark() >= 50) {
                count++;
        }
    }   
    
   return count;
   
    }
}