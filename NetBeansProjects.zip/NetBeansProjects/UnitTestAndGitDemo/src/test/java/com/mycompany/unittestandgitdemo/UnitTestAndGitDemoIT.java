/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.unittestandgitdemo;

import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class UnitTestAndGitDemoIT {
    
    public UnitTestAndGitDemoIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testSomeMethod() {
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class UnitTestAndGitDemo.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        UnitTestAndGitDemo.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of populateCity method, of class UnitTestAndGitDemo.
     */
    @Test
    public void testPopulateCity() {
        System.out.println("populateCity");
        String[] Cities = null;
        String[] Vehicle_Types = null;
        Scanner sc = null;
        int[][] expResult = null;
        int[][] result = UnitTestAndGitDemo.populateCity(Cities, Vehicle_Types, sc);
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateCityTotals method, of class UnitTestAndGitDemo.
     */
    @Test
    public void testCalculateCityTotals() {
        System.out.println("calculateCityTotals");
        String[] Cities = null;
        String[] Vehicle_Types = null;
        int[][] accidents = null;
        int[] expResult = null;
        int[] result = UnitTestAndGitDemo.calculateCityTotals(Cities, Vehicle_Types, accidents);
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getHighCity method, of class UnitTestAndGitDemo.
     */
    @Test
    public void testGetHighCity() {
        System.out.println("getHighCity");
        String[] Cities = null;
        int[] cityTotals = null;
        String expResult = "";
        String result = UnitTestAndGitDemo.getHighCity(Cities, cityTotals);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
