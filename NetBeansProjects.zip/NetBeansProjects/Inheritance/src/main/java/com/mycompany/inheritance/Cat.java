/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance;

/**
 *
 * @author lab_services_student
 */
public class Cat extends Animal {

    public Cat(String name, int age) {
        super(name, age);
    }

    @Override
    public String speak() {
        return "meow";
    }

    @Override
    public String move() {
        return "prowl";
    }

    public String describe() {
        return "Cat " + super.basicInfo() + " likes to " + move();
    }
}

