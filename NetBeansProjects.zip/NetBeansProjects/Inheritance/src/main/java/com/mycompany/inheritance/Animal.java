/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance;

/**
 *
 * @author lab_services_student
 */
public class Animal {
    
    // ========== BASE/ PARENT/ SUPER CLASS ===========
    /* the base class is used to keep track of value and
       behavours that are common to all child classes.
       In the example of an animal
       All animals have names and ages, all animals
       can walk and 'talk'
       But based on what subclass of animal you have
       The way they behave (ie talk / walk) or even the attributes they have
       can be is different so some animals wings
    */

        //Information hiding -> private class attributes
        private String name;
        private int age;
        
        //Base constructor
        /*
        A constructor is a special method that is created whenever you
        have a class. The purpose of a constructor is to set the values
        on any manditory class attributes. You can define a class construction
        [Below] but if you do not define one. Java creates an
        */
        
        public Animal(String name, int age) {
            /*
            to refer to the class attributes we use the 'this' keyword.
            This refers to this class. To access the param we just use their names
            */
            this.name = name;
            this.age = age;
            
        }
        
        /*
        We give safe access to class attributes using
        getters (returns the values of atrribututes) and
        setters (sets values of attributions
        */
        
        public String getName() {
            return this.name;
        }
        
        public int getAge() {
            return this.age;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        
        public void setAge(int age) {
            this.age = age;
            
        };
        
        //Behavior/ methods that can be different is the child 
        public String speak () {
            return "...";
        }
        
          public String move () {
            return "walk";
        }
          
          //What can't be overidden in a child class
          public final String kingdom() {
              return "some classification";
          }
          
          public static String Classification () {
              return "some classification";
           }
          private void secret () {}
          
          //helper method for subclasses
          public String basicInfo(){
              return name + "i" + age + ")";
          }

}