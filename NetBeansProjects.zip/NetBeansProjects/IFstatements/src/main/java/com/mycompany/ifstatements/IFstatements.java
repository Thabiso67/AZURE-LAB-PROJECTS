/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifstatements;

/**
 *
 * @author lab_services_student
 */
public class IFstatements {

    public static void main(String[] args) {
        
        
        int Age = 50; 
        
        if (Age > 10) {
            
            System.out.println("Age is greater than 10");
            
        }else{
            
            System.out.println("Age is not greater then 10");
            
        } 
    }
}
