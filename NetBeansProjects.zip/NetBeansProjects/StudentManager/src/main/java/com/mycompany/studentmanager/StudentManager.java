/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentmanager;

/**
 *
 * @author lab_services_student
 */
    class Student {
        String name;
        int age;
        double grade;
        
    public Student(String name, int age, double grade) {
        this.name = name; //this refers to the instance variable, name of the current object
        this.age = age; //Age on the right hand side is the constructor parameter
        this.grade = grade; //this.grade = grade;
                            //sets the instance variable to the value passed to the constructor
    }

    public void displayInfo() { //Method displaying created to display the instance variables
        System.out.println("Name: " + name + " | Age: " + age + " | Grade: " + grade);
    }
}

public class StudentManager {
    public static void main(String[] args) {
        Student[] students = {
            new Student("Alice", 18, 88.5),
            new Student("Bob", 19, 74.0),
            new Student("Charlie", 17, 92.3),
        };
        
        System.out.print(" Student Records:");
        for (Student s : students) {
            s.displayInfo();
        }
    }
}