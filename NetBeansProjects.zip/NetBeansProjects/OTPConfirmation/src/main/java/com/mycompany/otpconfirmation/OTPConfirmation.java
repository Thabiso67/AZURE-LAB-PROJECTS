/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.otpconfirmation;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class OTPConfirmation {

    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        
        int otp = new Random().nextInt(9000) + 1000; // 4- digit OTP
        JOptionPane.showMessageDialog(null, "Confirmation code to your phone " + otp);
        
        
        String enteredOTP = JOptionPane.showInputDialog("Enter Confirmation Code:");
        
        if (Integer.toString(otp).equals(enteredOTP)) {
            JOptionPane.showMessageDialog(null, "Registration Confirmed. Welcome, " + username + "!");
        }else{
            JOptionPane.showMessageDialog(null, "Incorrect code. Registration failed "
                   + "try putting the correct otp.");
        }
    }
}