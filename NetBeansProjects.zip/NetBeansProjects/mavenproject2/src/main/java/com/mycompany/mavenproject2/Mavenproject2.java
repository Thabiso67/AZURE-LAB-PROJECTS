/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author lab_services_student
 */
public class Mavenproject2 {

    public static void main(String[] args) {
        String Name = "John"; //Declaration of my String variable withidentifier Name
        String Surname = "Smith"; //Declaration of my String variable withidentifier Surname
        int Age = 15;  //Declaration of my integer variable with identifier Age
        double Height = 2.8; //Declaration of my double variable with identifier Height
        char CharacterExample = 'B';
        if(Age>17){
            System.out.println("You are 18 years or older, your are eligable to drive");
            
        }else{
            System.out.println("You are not 18 years or older, you are not eligable to drive");
            
        }
        /*
        
        I will now use my condition constructor if to
        specify that if you 18 years old you can drive
        
        */
        
        
        System.out.println("My Name is "+Name+ "My Surname is "
                +Surname+"I am "+Age+" Years old "
                        +"and my heigt is "+Height+"Meters");//Here we use the manipulation of Strings also called concantination
    }
}
