/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dowhilepassword;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class DoWhilePassword {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String correctPassword = "java123";
        String inputPassword;
        
        do{
            System.out.print("Enter password ");
            inputPassword = scanner.nextLine();
        }while (!inputPassword.equals(correctPassword));
        System.out.println("Access granted");
    }
}