/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.whileloop;

/**
 *
 * @author lab_services_student
 */
public class WhileLoop {

    public static void main(String[] args) {
        
        
        int a = 0;
        
        while(a<=12){
        System.out.println(a);
        a=a+2; //increment a by 2
        }
    }
}
