/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.moduleexample;

/**
 *
 * @author lab_services_student
 */
public class ModuleExample {

    public static void main(String[] args) {
        int Number1 = 40;
        int Number2 = 5;
        
        //using Modulus Operator
        
        int Total = Number1 % Number2 ;
        
        System.out.println("The remainder when "+Number1+
                " is divided by "+Number2+" is "+Total);
    }
}
