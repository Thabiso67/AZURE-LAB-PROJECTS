/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentscorearrayjoption;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class StudentScoreArrayJOption {

    public static void main(String[] args) {
        int studentCount = Integer.parseInt(
            JOptionPane.showInputDialog("Enter number of students: ")
                
        );
        String[] names = new String[studentCount];
        int[] scores = new int[studentCount];
        
        //input names and scores
        for (int i=0;i<studentCount;i++){
            names[i] = JOptionPane.showInputDialog("Enter name of student"+(i+1)+":");
            String scoreInput = JOptionPane.showInputDialog("Enter score for "+names[i]+":");
            scores[i] = Integer.parseInt(scoreInput);
            
            
            //Calculate total and average
            int total = 0;
            int highest = scores[0];
            String topStudent = names[0];
            
            for (int i = 0;i<studentCount;i++) {
                total +=scores[i];
                 if (scores[1]>highest) {
                     highest = scores [1];
                     topStudent = names[1];
                     
                 }
            }
            
            double average = (double) total/ studentCount;
            
           //Build the result message
           StringBuilder result = new StringBuilder("Student Score: \n");
           for (int i = 0; i<studentCount;i++){
               result.append(names[i]).append(":").append(scores[i]).append("\n");
               
           }
           result.append("\nAverage Score: ").append(String.format("%2f", average));
           result.append("\nHighest Score: ").append(highest).append("(").append(topStudent).append("(");
           
           //show result
           JOptionPane.showMessageDialog(null, result.toString(),"Result",JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
