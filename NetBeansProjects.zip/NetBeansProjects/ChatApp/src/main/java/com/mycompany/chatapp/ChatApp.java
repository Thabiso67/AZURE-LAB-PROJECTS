package com.mycompany.chatapp;

import java.util.ArrayList;
import java.util.UUID;

public class ChatApp {
    private String id;               // Unique message ID
    private String sender;          // Sender's username
    private String recipient;       // Recipient's contact number
    private String message;         // Message content
    private static int totalMessagesSent = 0;

    private static final ArrayList<ChatApp> sentMessages = new ArrayList<>();

    // Constructor
    public ChatApp(String sender, String recipient, String message) {
        this.id = UUID.randomUUID().toString();
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;
    }

    // Called when a message is sent
    public String SentMessage() {
        totalMessagesSent++;
        sentMessages.add(this);
        return "Message sent (ID: " + this.id + ")";
    }

    // Show full message
    public String printMessages() {
        return "ID: " + id +
               "\nFrom: " + sender +
               "\nTo: " + recipient +
               "\nMessage: " + message;
    }

    // Return total number of messages sent
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // Show all messages
    public static String showAllMessages() {
        if (sentMessages.isEmpty()) return "No messages have been sent yet.";

        StringBuilder sb = new StringBuilder();
        for (ChatApp m : sentMessages) {
            sb.append(m.printMessages()).append("\n\n");
        }
        return sb.toString();
    }

    // Get the longest message
    public static String getLongestMessage() {
        if (sentMessages.isEmpty()) return "No messages to analyze.";

        ChatApp longest = sentMessages.get(0);
        for (ChatApp m : sentMessages) {
            if (m.message.length() > longest.message.length()) {
                longest = m;
            }
        }

        return "Longest Message:\n" + longest.printMessages();
    }

    // Search by ID
    public static String searchById(String id) {
        for (ChatApp m : sentMessages) {
            if (m.id.equals(id)) {
                return "Message Found:\nTo: " + m.recipient + "\nMessage: " + m.message;
            }
        }
        return "Message with ID not found.";
    }

    // Search by recipient number
    public static String searchByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        for (ChatApp m : sentMessages) {
            if (m.recipient.equals(recipient)) {
                sb.append(m.printMessages()).append("\n\n");
            }
        }
        return sb.length() == 0 ? "No messages to this recipient." : sb.toString();
    }

    // Delete message using hash
    public static String deleteByHash(String hash) {
        for (ChatApp m : sentMessages) {
            if (String.valueOf(m.id.hashCode()).equals(hash)) {
                sentMessages.remove(m);
                return "Message with hash " + hash + " deleted.";
            }
        }
        return "No message found with this hash.";
    }

    // Full report
    public static String fullReport() {
        if (sentMessages.isEmpty()) return "No messages available.";
        StringBuilder sb = new StringBuilder("=== Message Report ===\n");
        for (ChatApp m : sentMessages) {
            sb.append(m.printMessages())
              .append("\nHash: ").append(m.id.hashCode())
              .append("\n-------------------\n");
        }
        return sb.toString();
    }
}
