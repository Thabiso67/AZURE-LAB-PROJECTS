/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.myvariables;

/**
 *
 * @author lab_services_student
 */
public class MyVariables {

    public static void main(String[] args) {
       
        String
    }
}
