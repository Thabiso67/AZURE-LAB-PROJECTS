import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class TVSeriesApp {

    // ====== Inner "model" class ======
    static class SeriesModel {
        public String SeriesId;
        public String SeriesName;
        public String SeriesAge;
        public String SeriesNumberOfEpisodes;

        public SeriesModel(String id, String name, String age, String episodes) {
            this.SeriesId = id;
            this.SeriesName = name;
            this.SeriesAge = age;
            this.SeriesNumberOfEpisodes = episodes;
        }

        @Override
        public String toString() {
            return String.format("ID: %s | Name: %s | Age: %s | Episodes: %s",
                    SeriesId, SeriesName, SeriesAge, SeriesNumberOfEpisodes);
        }
    }

    // ====== Storage & Scanner ======
    private final List<SeriesModel> seriesDb = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    // ====== Main Menu Loop ======
    private void start() {
        while (true) {
            printMenu();
            System.out.print("Choose an option (1-6): ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> CaptureSeries();
                case "2" -> SearchSeries();
                case "3" -> UpdateSeries();
                case "4" -> DeleteSeries();
                case "5" -> SeriesReport();
                case "6" -> ExitSeriesApplication();
                default -> System.out.println("Invalid option. Please try again.\n");
            }
        }
    }

    private void printMenu() {
        System.out.println("""
                ================== TV Series Manager ==================
                1. Capture a new TV series
                2. Search for a series
                3. Update a series
                4. Delete a series
                5. View series report
                6. Exit
                =======================================================
                """);
    }

    // ====== Features ======
    private void CaptureSeries() {
        System.out.println("\n=== Capture New Series ===");

        System.out.print("Enter Series ID: ");
        String id = scanner.nextLine().trim();

        System.out.print("Enter Series Name: ");
        String name = scanner.nextLine().trim();

        String age = promptValidAge();
        String episodes = promptPositiveInt("number of episodes");

        SeriesModel model = new SeriesModel(id, name, age, episodes);
        seriesDb.add(model);

        System.out.println("Series details have been successfully saved.\n");
    }

    private void SearchSeries() {
        System.out.print("Enter Series ID to search: ");
        String id = scanner.nextLine().trim();
        SeriesModel found = findById(id);

        if (found != null) {
            System.out.println("Series found: " + found + "\n");
        } else {
            System.out.println("Error: No series data could be found.\n");
        }
    }

    private void UpdateSeries() {
        System.out.print("Enter Series ID to update: ");
        String id = scanner.nextLine().trim();
        SeriesModel found = findById(id);

        if (found == null) {
            System.out.println("Error: Series not found.\n");
            return;
        }

        System.out.printf("Current Name (%s). Enter new name or press ENTER to keep: ", found.SeriesName);
        String name = scanner.nextLine();
        if (!name.isBlank()) found.SeriesName = name.trim();

        System.out.printf("Current Age (%s). Enter new age or press ENTER to keep: ", found.SeriesAge);
        String ageInput = scanner.nextLine();
        if (!ageInput.isBlank()) found.SeriesAge = promptValidAge(ageInput);

        System.out.printf("Current Episodes (%s). Enter new episodes or press ENTER to keep: ", found.SeriesNumberOfEpisodes);
        String epInput = scanner.nextLine();
        if (!epInput.isBlank()) found.SeriesNumberOfEpisodes = promptPositiveInt("number of episodes", epInput);

        System.out.println("Series updated successfully.\n");
    }

    private void DeleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String id = scanner.nextLine().trim();
        SeriesModel found = findById(id);

        if (found == null) {
            System.out.println("Error: Series not found.\n");
            return;
        }

        System.out.println("Found: " + found);
        System.out.print("Are you sure you want to delete this series? (Y/N): ");
        String confirm = scanner.nextLine().trim().toUpperCase(Locale.ROOT);

        if (confirm.equals("Y")) {
            seriesDb.remove(found);
            System.out.println("Series deleted successfully.\n");
        } else {
            System.out.println("Deletion cancelled.\n");
        }
    }

    private void SeriesReport() {
        if (seriesDb.isEmpty()) {
            System.out.println("No series captured yet.\n");
            return;
        }

        System.out.printf("%-8s | %-20s | %-5s | %-8s%n", "ID", "Name", "Age", "Episodes");
        System.out.println("-----------------------------------------------");
        for (SeriesModel s : seriesDb) {
            System.out.printf("%-8s | %-20s | %-5s | %-8s%n",
                    s.SeriesId, s.SeriesName, s.SeriesAge, s.SeriesNumberOfEpisodes);
        }
        System.out.println();
    }

    private void ExitSeriesApplication() {
        System.out.println("Exiting application. Goodbye!");
        System.exit(0);
    }

    // ====== Helpers ======
    private SeriesModel findById(String id) {
        for (SeriesModel s : seriesDb) {
            if (s.SeriesId.equalsIgnoreCase(id)) return s;
        }
        return null;
    }

    private String promptValidAge() {
        while (true) {
            System.out.print("Enter Age Restriction (2-18): ");
            String input = scanner.nextLine().trim();
            if (input.matches("\\d+")) {
                int age = Integer.parseInt(input);
                if (age >= 2 && age <= 18) return input;
                else System.out.println("Age must be between 2 and 18.");
            } else {
                System.out.println("Invalid input. Numbers only.");
            }
        }
    }

    private String promptValidAge(String firstAttempt) {
        String attempt = firstAttempt.trim();
        while (true) {
            if (attempt.matches("\\d+")) {
                int age = Integer.parseInt(attempt);
                if (age >= 2 && age <= 18) return attempt;
                else System.out.println("Age must be between 2 and 18.");
            } else {
                System.out.println("Invalid input. Numbers only.");
            }
            System.out.print("Enter Age Restriction (2-18): ");
            attempt = scanner.nextLine().trim();
        }
    }

    private String promptPositiveInt(String field) {
        while (true) {
            System.out.printf("Enter %s: ", field);
            String input = scanner.nextLine().trim();
            if (input.matches("\\d+") && Integer.parseInt(input) > 0) return input;
            System.out.printf("Invalid input. %s must be positive.%n", field);
        }
    }

    private String promptPositiveInt(String field, String firstAttempt) {
        String attempt = firstAttempt.trim();
        while (true) {
            if (attempt.matches("\\d+") && Integer.parseInt(attempt) > 0) return attempt;
            System.out.printf("Invalid input. %s must be positive.%n", field);
            System.out.printf("Enter %s: ", field);
            attempt = scanner.nextLine().trim();
        }
    }

    // ====== Main Method ======
    public static void main(String[] args) {
        new TVSeriesApp().start();
    }
}
