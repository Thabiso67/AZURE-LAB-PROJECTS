/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.writetotextfile;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class WriteToTextFile {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String fileName = "text.txt"; //File will be created or overwritten in the project folder
        
        System.out.println("Enter text to write to 'text.txt' (type 'exit' to finish):");
        
        try (FileWriter writer = new FileWriter(fileName)) {
            while (true) {
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("exit")) {
                    break;
                    
                }
                writer.write(input + System.lineSeparator());
            }
            System.out.println("Text succesfully written to 'text.txt'");
        } catch (IOException e) {
            System.out.println("An error occured while writing to  the file.");
            e.printStackTrace();
        }
}
}