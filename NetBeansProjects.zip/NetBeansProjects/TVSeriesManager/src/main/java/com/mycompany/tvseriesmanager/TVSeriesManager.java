/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tvseriesmanager;



/**
 *
 * @author lab_services_student
 */


// Data model class that holds the details for a single TV series
public class TVSeriesManager {
    public String SeriesId;
    public String SeriesName;
    public String SeriesAge;
    public String SeriesNumberOfEpisodes;

    // Constructor to initialize a new TV series object
    public TVSeriesManager(String id, String name, String age, String episodes) {
        this.SeriesId = id;
        this.SeriesName = name;
        this.SeriesAge = age;
        this.SeriesNumberOfEpisodes = episodes;
    }

    // Nicely formatted string for display in reports and search results

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "SeriesId=" + SeriesId +
               ", Name=" + SeriesName +
               ", Age=" + SeriesAge +
               ", Episodes=" + SeriesNumberOfEpisodes;
    }
}