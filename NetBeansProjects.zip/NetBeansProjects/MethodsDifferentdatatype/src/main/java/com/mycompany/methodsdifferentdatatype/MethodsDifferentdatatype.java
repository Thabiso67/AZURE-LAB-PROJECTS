/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methodsdifferentdatatype;

/**
 *
 * @author lab_services_student
 */
public class MethodsDifferentdatatype {
    //Creating a method that takes integer datatypes
    public static int IntegerNumbers(int a, int b) {
        return a+b;
    }
    //Creating a method that takes double datatypes
    public static double DoubleNumbers(double Num1, double Num2){
        return Num1*Num2;
    }
    //Creating a method with no parameters
    
    
    public static String GetFixedString() {
        return "Hello, I am John";

    }
    public static void main(String[] args){
            //calling methods
            int x = 20;
            int y = 30;
            double k = 10.5;
            double p = 5.8;
            int sum = IntegerNumbers(x,y);
            double product = DoubleNumbers(k,p);
            String MyString = GetFixedString();
            
            System.out.println("The sum of the two numbers is: " +sum
            +"\nThe product of two numbers is: "+ product+
              "\n"+MyString);
    }
    
}
