/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dialogexample;
import javax.swing.JOptionPane;
/**
 *
 * @author lab_services_student
 */
public class DialogExample {

    public static void main(String[] args) {
        
        String name;
        String surname;
        String StuNumber;
        
        name = JOptionPane.showInputDialog(null,"Enter Your Name:");
        surname = JOptionPane.showInputDialog(null,"Enter Your Surname: ");
        StuNumber = JOptionPane.showInputDialog(null,"What is Your StudentNumber:");
        JOptionPane.showMessageDialog(null,"Name: "+name+" \nSurname: "+surname+
                "\nStudent Number: "+StuNumber);
    }
}