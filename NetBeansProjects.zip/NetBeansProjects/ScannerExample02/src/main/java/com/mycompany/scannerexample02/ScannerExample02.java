/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.scannerexample02;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class ScannerExample02 {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
         //Ask the student for the Name
        System.out.print("Please enter your Name");
        String StudentName = scanner.nextLine();
        
        //Ask the student for the Student number
        System.out.print("Please enter your Student Number");
        String StudentNumber = scanner.nextLine();
        
        //Ask the user for their Grade
        System.out.print("Please enter your Grade");
        double Grade = scanner.nextDouble();
        
        //use Condition constructions to check if the student passed
        if(Grade>49){
        System.out.println("Hello: "+StudentName+" You have passed");
        }else{
            System.out.println("Hello: "+StudentNumber+" You have failed");
        }
    }
}
