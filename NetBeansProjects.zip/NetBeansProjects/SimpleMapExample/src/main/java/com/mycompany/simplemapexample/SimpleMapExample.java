/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simplemapexample;

import java.util.HashMap;

/**
 *
 * @author lab_services_student
 */
public class SimpleMapExample {

    public static void main(String[] args) {
        //Create a dictionary (HashMap)
        HashMap<String, String> fruitColours = new HashMap<>();
        
        //Add some items
        fruitColours.put("Apple", "Red");
        fruitColours.put("Banana", "Yellow");
        fruitColours.put("Grapes", "Green");
        
        //Retrieve and print values
        System.out.println("Color of Apple: " + fruitColours.get("Apple"));
        System.out.println("Color of Banana: " + fruitColours.get("Banana"));
        System.out.println("Color of Grapes: " + fruitColours.get("Grapes"));
    }
}
