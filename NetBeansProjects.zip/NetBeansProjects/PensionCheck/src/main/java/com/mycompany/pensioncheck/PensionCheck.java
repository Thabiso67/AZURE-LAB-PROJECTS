/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pensioncheck;
import javax.swing.JOptionPane;
/**
 *
 * @author lab_services_student
 */
public class PensionCheck {

    public static void main(String[] args) {
       String Name = JOptionPane.showInputDialog("Enter Your Name");
       String age = JOptionPane.showInputDialog("Enter Your Age");
       
       int Age = Integer.parseInt(age);
       
        if(Age>=50){
            JOptionPane.showMessesageDialog(null, "Name: " +Name+ "Age: " +Age+ "You are eligable for a pension");  
        }else{
            JOptionPane.showMessesageDialog(null, "Name: " +Name+ "Age: " +Age+ "Your are not eligable for a pension");
          
        }
    }
}
