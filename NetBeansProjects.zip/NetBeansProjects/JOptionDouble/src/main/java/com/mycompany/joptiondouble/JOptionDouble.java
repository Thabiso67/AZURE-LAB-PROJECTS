/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.joptiondouble;
import javax.swing.JOptionPane;
/**
 *
 * @author lab_services_student
 */
public class JOptionDouble {

    public static void main(String[] args) {
        //Prompt the user input
        String input1 = JOptionPane.showInputDialog("Enter your First Double value");
        String input2 = JOptionPane.showInputDialog("Enter your Second Double value");
        //Convert Strings input to double
        double numb1 = Double.parseDouble(input1);
        double numb2 = Double.parseDouble(input2);
 
        //Calculate the product
        double product = numb1 + numb2 ;
        //Displaying the result
        JOptionPane.showMessageDialog(null,"The product of: "+numb1+
                " and: "+numb2+" is: "+product);
    }
}
