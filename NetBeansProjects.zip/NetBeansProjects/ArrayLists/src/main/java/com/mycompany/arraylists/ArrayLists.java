/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraylists;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

/**
 *
 * @author lab_services_student
 */
public class ArrayLists {

    public static void main(String[] args) {
        
        //An arraylist is just a list
        //You can think of it as an array
        //The key diffirence between and arraylist and an array is an arraylist has no fixed
        //To  create an empty arraylist (java.util.ArrayList)
        
        ArrayList<String> todo = new ArrayList<>();
        int [] arr = new int[5];
        
        //To add to an arraylist
        todo.add("Buy Milk");
        todo.add("Finish Lab");
        todo.add("Email Lecturer");
        
        //to display print an array list
        System.out.println("Todo: " + todo);
        
        //when you add to a specific index in array list,
        //all elements that are an index => the index we are adding to
        //get pushed to the right
        //syntax to add
        todo.add(1, "Have lunch");
        System.out.println("Todo: " + todo);
        
        //to get an element at a specific index
        String firstItem = todo.get(0);
        System.out.println("First task :" + firstItem);
        
        //To add to a specific index and overide
        todo.set(0, "Buy Almond Milk");
        System.out.println("New List : " +todo);
        
        //To search within an arraylist
        System.out.println("Does list contains \"Finish Lab\"" + todo.contains("Finish Lab"));
        //To search for index of element
        System.out.println("Index of \"Email Lecturer\"" + todo.indexOf("Email Lecturer"));
        
        
        //To iterate through any Array list
        //The same and an array
        for ( int i = 0; i < todo.size(); i++) {
            System.out.println(i +" "+ todo.get(i));
        }
        
        for ( String task : todo ) {
            System.out.println(task);
        }
        
        System.out.println("Iterator");
        Iterator<String> it = todo.iterator();
        while ( it.hasNext () ){
            System.out.println(it.next());
            
        }
        
        //Bulk operations (Bulk Add)
        todo.addAll(Arrays.asList("Clean Desk","Sketch"));
        System.out.println("After addAll :" + todo);
    }
}
