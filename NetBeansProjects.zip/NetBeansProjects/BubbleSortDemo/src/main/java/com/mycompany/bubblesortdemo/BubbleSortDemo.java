/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bubblesortdemo;

/**
 *
 * @author lab_services_student
 */
public class BubbleSortDemo {

    public static void main(String[] args) {
        
        
        char [] arr = {'s','a','e','x','t'};
        
        
        
        // arr[0] > arr[i] checks if arr[0] appears after arr[1] in the alphabet
        
        
        
    }
}
