/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraysortdescending;

import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author lab_services_student
 */
public class ArraySortDescending {

    public static void main(String[] args) {
        Integer[] numbers = {5,2,8,1,9,10,3,6,4,7};
        
        Arrays.sort(numbers,Collections.reverseOrder());// Sort in descending
        
        System.out.println("Sorted in Descending Order");
        
        System.out.println("Sorted in Descending Order: " + Arrays.toString(numbers));
        
    }
}
