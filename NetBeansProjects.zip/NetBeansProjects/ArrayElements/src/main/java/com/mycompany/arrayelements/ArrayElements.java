/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arrayelements;

/**
 *
 * @author lab_services_student
 */
public class ArrayElements {

    public static void main(String[] args) {
        int[] numbers = {10,20,30,40,50,60,70,80,90,100};
        //Let us try access the elements on our Array numbers
        System.out.println("First element: "+ numbers[0]);
        System.out.println("Second element: "+ numbers[1]);
        System.out.println("Third element: "+ numbers[2]);
        System.out.println("Fourth element: "+ numbers[3]);
        System.out.println("Fifth element: "+ numbers[4]);
        System.out.println("Sixth element: "+ numbers[5]);
        System.out.println("Seventh element: "+ numbers[6]);
        System.out.println("Eight element: "+ numbers[7]);
        System.out.println("Ninth element: "+ numbers[8]);
        System.out.println("Tenth element: "+ numbers[9]);
    }
}