/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.emaillogin;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class EmailLogin {

    public static String savedEmail;
    public static String savedPassword;
    
    public static boolean isValidEmail(String email) {
    return email.matches("^[\\w.-]+\\.[a-zA-Z](2,6)$");
        
    }
   
    public static boolean isValidPassword(String password){
        return password.length() >= 8 && !password.equals(password.toLowerCase())&&
               password.matches(".*\\d.*") && !password.matches("[A-Za-z0-9]*");

}

    public static void main(String[] args) {
        String email = JOptionPane.showInputDialog("Enter your email:");
        String password = JOptionPane.showInputDialog("Enter your Password:");

        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(null, "Invalid email format.");
            return;
} 
        if (!isValidPassword(password)) {
            JOptionPane.showMessageDialog(null, "Password must 8+ characters");
            return;

}
        savedEmail = email;
        savedPassword = password;
        JOptionPane.showMessageDialog(null, "Registration Successful");

        String loginEmail = JOptionPane.showInputDialog("Enter email to login");
        String loginPass = JOptionPane.showInputDialog("Enter password");

        if (loginEmail.equals(savedEmail) && loginPass.equals(savedPassword)){
            JOptionPane.showMessageDialog(null, "Login successful!");
        }else{
           JOptionPane.showMessageDialog(null, "Login failed. Incorrect email or password.");
        
    }
    }
}
