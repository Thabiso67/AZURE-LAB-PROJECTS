/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simplearray;

/**
 *
 * @author lab_services_student
 */
public class SimpleArray {

    public static void main(String[] args) {
        int[] numbers = {10,20,30,40,50};
        
        for (int i=0; i< numbers.length; i++){
            System.out.println("Element at index "+i+":"+numbers[i]);
            
        }
        
    }
}
