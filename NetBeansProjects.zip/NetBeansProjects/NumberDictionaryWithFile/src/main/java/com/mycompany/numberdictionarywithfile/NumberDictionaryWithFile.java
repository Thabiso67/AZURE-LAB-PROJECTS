/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numberdictionarywithfile;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class NumberDictionaryWithFile {

    public static void main(String[] args) throws IOException {
        //Allow the user to make input
        Scanner scanner = new Scanner(System.in);
        //Allow for storing and retrieval on our dictionary
        HashMap<String, Integer> dictionary = new HashMap<>();
        //Asking the user the number of entries
        System.out.print("How many entries do you want to add? ");
        //we capture the number of entries as a string and convert it to integer
        int count = Integer.parseInt(scanner.nextLine());
        
        // Input and update
        // Initialize out i so that we can be to do increment(i=i+i)
        for (int i = 0; i < count; i++) {
            //Asking the user to enter a Name or Key
            System.out.print("Enter name/key: ");
            //we store our name or key on the variable key
            String key = scanner.nextLine();
            //Asking the user to enter a number or value that corraspond with the entered Name
            System.out.print("Enter number/value for '" + key + "': ");
            //Receive the number as a string and than convert it to an integer
            int value = Integer.parseInt(scanner.nextLine());
            //checking our dictionary that we created if it contains key
            if (dictionary.containsKey(key)) {
                //Display the key if it is already stored on the dictionary
                System.out.println("Key already exists! Old value: " + dictionary.get(key));
                //Adding a value that will correspond with the name or key
                System.out.println("Updating to new value: " + value);
            }
            
            dictionary.put(key, value);
            System.out.println("Added/Update: " + key + " => " + value + "\n");
        }
        
        //Lookup
        System.out.print("Enter a name/key to look up: ");
        String searchKey = scanner.nextLine();
        
        if(dictionary.containsKey(searchKey)) {
            System.out.println("Value for '" + searchKey + "': " + dictionary.get(searchKey));
        } else { 
            System.out.println("Key not found.");
            
        }
        
        //Save to file
        try {
            FileWriter writer = new FileWriter("dictionary");
            for (String key : dictionary.keySet()) {
                writer.write(key + ": " + dictionary.get(key) + "\n");
            }
            writer.close();
            System.out.println("\nDictionary saved to 'dictionary.txt'.");
        } catch (IOException e) {
            System.out.println("Error saving to file: " + e.getMessage());
        }
    
    scanner.close();
}
}