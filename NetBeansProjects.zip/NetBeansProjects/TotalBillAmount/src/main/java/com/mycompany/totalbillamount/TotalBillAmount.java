/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.totalbillamount;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class TotalBillAmount {

    public static void main(String[] args) {
        //Prompt the user for the amount if they are a student
        String Amount = JOptionPane.showInputDialog("Enter an ammount if you are a student");
        //Convert string to double
        double AmountDouble = Double.parseDouble (Amount);
        //Multiply the amount which has been coverted to double 10%
        double Total = AmountDouble*0.10;
        //deduct the 10% rate from the original amount which is AmountDouble
        double Total01 = AmountDouble-Total;
        //Display the Result
        JOptionPane.showMessageDialog(null, "Total amount after "+"deduction of 10 is: "+Total01+" Rands");
    }
}
