/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.movieticketpricecalculator;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class MovieTicketPriceCalculator {

    public static void main(String[] args) {
         String age = JOptionPane.showInputDialog("Enter Your Age");
         
         
            int Age = Integer.parseInt(age);
            
              if(Age<=5){
            JOptionPane.showMessesageDialog(null, "Age: " +Age+ "Ticket is free");
            
            
          
    }
}
