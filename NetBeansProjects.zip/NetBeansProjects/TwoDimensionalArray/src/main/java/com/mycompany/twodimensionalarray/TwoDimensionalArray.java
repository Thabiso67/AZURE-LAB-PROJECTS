/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.twodimensionalarray;

/**
 *
 * @author lab_services_student
 */
public class TwoDimensionalArray {

    public static void main(String[] args) {
        
        //creating an empty array,
        //you have to create an empty array with dimesions (num of rows and cols)
        int [] [] arr2D = new int [5] [5];
        
        //creating an array and populating it.
        int [][] arr2D1 = {{1,2,3),
                          {4,5,6
                              {
                                  
                                  
                                  
                                  
                              }
                          }
    }
    }
}