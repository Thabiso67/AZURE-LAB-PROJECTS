/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.enums;

/**
 *
 * @author lab_services_student
 */
public class Enums {

    public static void main(String[] args) {
        //Enums are kind of like a class
        //They have 'variables'
        //They can have functions/methods
        //The difference ois emnus are used for constant values
        //Emnus are when you know what values will be
        //when you know you will be using those values often
        //when you know you won'tbe need to change them or add to them
        
        enum TrafficLight {
            RED("Red",3D,true),
            YELLOW("YELLOW",5,false),
            GREEN("GREEN",25,false),
            
            private final String label;
            private final int duration;
            private final boolean stop;
            
            TrafficLight(String label, int duration, boolean stop) {
                  this.label = label;
                  this.duration = duration;
                  this.stop = stop;
        }
            
            String lable() (return label;)
            int duration() (return duration;)
            boolean isStop () (return stop;)
            
            TrafficLight next()
                switch (this) { 
            
        }
    }
}
