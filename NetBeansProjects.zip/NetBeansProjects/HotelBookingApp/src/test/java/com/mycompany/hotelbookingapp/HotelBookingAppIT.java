/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.hotelbookingapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */



public class HotelBookingAppIT {

    @BeforeEach
    public void setUp() {
        // Reset the hotel rooms before each test
        HotelBookingApp.main(new String[]{}); // This initializes the rooms
    }

    @Test
    public void testBookRoom_Success() {
        HotelBookingApp.bookRoom(101);
        // Try booking again should say "already booked"
        assertTrue(findRoom(101).isBooked());
    }

    @Test
    public void testBookRoom_AlreadyBooked() {
        HotelBookingApp.bookRoom(101);
        HotelBookingApp.bookRoom(101); // Tells the user to book again
        assertTrue(findRoom(101).isBooked()); // Tells the user the room is still booked
    }

    @Test
    public void testBookRoom_RoomNotFound() {
        HotelBookingApp.bookRoom(999); //Tells the user the room doesn’t exist
        assertNull(findRoom(999));
    }

    @Test
    public void testCancelRoom_Success() {
        HotelBookingApp.bookRoom(102);
        HotelBookingApp.cancelRoom(102);
        assertFalse(findRoom(102).isBooked());
    }

    @Test
    public void testCancelRoom_NotBooked() {
        HotelBookingApp.cancelRoom(201); //Tells the user the room is not booked yet
        assertFalse(findRoom(201).isBooked());
    }

    @Test
    public void testCancelRoom_RoomNotFound() {
        HotelBookingApp.cancelRoom(999);
        assertNull(findRoom(999));
    }

    //Helper method to access the state of the room
    private Room findRoom(int number) {
        try {
            java.lang.reflect.Field field = HotelBookingApp.class.getDeclaredField("rooms");
            field.setAccessible(true);
            Room[] rooms = (Room[]) field.get(null);
            for (Room r : rooms) {
                if (r.getRoomNumber() == number) {
                    return r;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
