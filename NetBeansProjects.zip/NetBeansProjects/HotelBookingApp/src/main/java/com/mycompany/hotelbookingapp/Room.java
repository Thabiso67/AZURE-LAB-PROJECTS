/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelbookingapp;

/**
 *
 * @author lab_services_student
 */
    // ===== Base class =====
public class Room {
    private int roomNumber;
    private boolean booked;

    public Room(int roomNumber) {
        this.roomNumber = roomNumber;
        this.booked = false;
    }

    public int getRoomNumber() { return roomNumber; }
    public boolean isBooked() { return booked; }
    public void book() { this.booked = true; }
    public void cancel() { this.booked = false; }

    @Override
    public String toString() {
        return String.format("Room %d | Type: %s | Status: %s",
                roomNumber, this.getClass().getSimpleName(),
                booked ? "Booked" : "Available");
    }
}