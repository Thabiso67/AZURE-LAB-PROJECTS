/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quizzeacess;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class QuizzeAcess {

    public static void main(String[] args) {
        final String accessCode = "QUIZ123";
        
        String name = JOptionPane.showInputDialog("Enter your name:");
        String code = JOptionPane.showInputDialog("Enter access code to start the quiz:");
        
        if  (code.equals(accessCode)) {
            JOptionPane.showMessageDialog(null, "Acess granted. Good luck. " + name + "!");
        }else{
            JOptionPane.showMessageDialog(null, "Access denied. Incorrect code.");
        }
    }
}