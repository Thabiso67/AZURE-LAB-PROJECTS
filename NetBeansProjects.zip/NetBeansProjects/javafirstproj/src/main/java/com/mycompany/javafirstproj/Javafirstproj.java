/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javafirstproj;

/**
 *
 * @author lab_services_student
 */
public class Javafirstproj {

    public static void main(String[] args) {
        
        
        //Here I have declared my variable  which is of string data type
        String Name = "Thabiso";
        
        int Age = 30 ;                //Here  I have declared my variable as of interger data type
        int Number01 = 25 ;           //Here  I have declared my variable as of interger data type
        int Number02 = 35 ;           //Here  I have declared my variable as of interger data type
        
        int Sum = Number01 + Number02;
                
        System.out.println(Name);
        System.out.println(Age);
        System.out.println(Sum);
        
        System.out.println("My name is "+ Name + "I am " + Age + " Years Old");
                
    }
}
