/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simplemapexample2;
import java.util.HashMap;

/**
 *
 * @author lab_services_student
 */
public class SimpleMapExample2 {

    public static void main(String[] args) {
       HashMap<String, String> carModels = new HashMap<>();
       
        carModels.put("Toyota", "Hilux");
        carModels.put("Nissan", "Navara");
        carModels.put("Audi", "A3");
        carModels.put("Ford", "Ranger");
        carModels.put("Fiat", "Bravo");
        
        System.out.println("Model of Toyota: " + carModels.get("Toyota"));
        System.out.println("Model of Nissan: " + carModels.get("Nissan"));
        System.out.println("Model of Audi: " + carModels.get("Audi"));
        System.out.println("Model of Ford: " + carModels.get("Ford"));
        System.out.println("Model of Fiat: " + carModels.get("Fiat"));
    }
}