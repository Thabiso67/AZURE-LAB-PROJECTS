/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.takeintegerinput;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class TakeIntegerInput {
    
    //Mathod that takes Integer
    public static void takeIntegerInput(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your integer");
        String input = scanner.nextLine();
        System.out.println("The String you entered is "+input);
    }

    public static void main(String[] args) {
        takeIntegerInput();
    }
}
