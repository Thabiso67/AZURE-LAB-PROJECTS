/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraylistandarrays;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author lab_services_student
 */
public class ArrayListAndArrays {

        
        
        static class Student {
            String name;
            int grade; 
            
            Student(String name, int grade) {
                this.name = name;
                this.grade = grade;
        }
            
            @Override
            public String toString(){
                return name + "(" + grade + ")";
            }
    }
        


      public static void main(String[] args) {
          
            // In java "Array" is a built in type, classes/types come with methods and class variables
            // java.otil.Arrays has many useful methods
            // to use Array class you need the import statement import java.util.Arrays
            
            //1) Create a 1D array for grades
            int [] score = { 88, 95, 70, 100, 92 };
            
            //The Array class has a toString method
            System.out.println("Orginal scores: "+ Arrays.toString(score));
            
            //The Array class  has a sort method
            Arrays.sort(score);
            System.out.println("After sort:"  + Arrays.toString(score));
            
            //The array class has a search method
            int index = Arrays.binarySearch(score, 95);
            System.out.println("Index of 95 is :" + index);
            
            //The array allows you to copy on array into another
            //The company of one array does not modify the copied
            //int[] scoreDesc = Arrays.sort(score, Collective.reverseOrder);
            
            int[] bottom3 = Arrays.copyOf(score, 3);
            int[] subArray = Arrays.copyOfRange(score, 2, 4);
            int[] top3 = Arrays.copyOfRange(score, score.length -3 , score.length);
            System.out.println("Bottom 3:"  + Arrays.toString(bottom3));
            System.out.println("Top 3:"  + Arrays.toString(top3));
            System.out.println("The subnet is:"  + Arrays.toString(subArray));
            
            //Fill an array and set everything to the same value
            int [] allFourtyFour = new int[5];
            Arrays.fill(allFourtyFour, 44);
            System.out.println("44 array :" + Arrays.toString(allFourtyFour));
            
            //Arrays calss can can be used to print 2D arrays
            int [][] grid = {[1,2],{3,4]};
            System.out.println("2D grid :" + Arrays.deepToString(grid));
            
            
            //Creating an array of Students
            Student[] students = {
                new Student("Alisha", 76),
                new Student("Ben", 91),
                new Student("Chloe", 85),
                new Student("Dumi", 91),
                
                
            };
            
            
            System.out.println("Students (original)) :" + Arrays.toString(students));
            
            //Sorting an array of custom types  (classes that you created)
            
            Arrays.sort(students, Comparator
                    .comparingInt((Student s ) ->s.grade)
                    .thenComparing(s -> s.name));
            
            
            System.out.println("Ordered student: " + Arrays.toString(students));
            
            
            
            
            
      }
            
      }