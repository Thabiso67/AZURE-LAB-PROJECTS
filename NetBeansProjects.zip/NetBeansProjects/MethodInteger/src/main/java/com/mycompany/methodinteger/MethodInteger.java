/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methodinteger;

/**
 *
 * @author lab_services_student
 */
public class MethodInteger {
    
    
    //Creating my method
    public static int getFixedNumber(){
        return 25;
        
        
    }
    public static void main(String[] args) {
        
        int result = getFixedNumber();
        
        
        System.out.println("The result is: "+result);
    }
}
