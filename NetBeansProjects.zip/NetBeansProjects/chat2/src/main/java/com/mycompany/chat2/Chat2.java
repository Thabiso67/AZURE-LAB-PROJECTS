/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chat2;

/**
 *
 * @author lab_services_student
 */

import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;

public class Chat2 {

    private static int messageCounter = 0;
    private static final List<Chat2> sentMessages = new ArrayList<>();
    private static final JSONArray storedMessages = new JSONArray();

    private final String messageID;
    private final String recipient;
    private final String message;
    private final String messageHash;

    public Chat2(String recipient, String message) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }

    // Method: Generate unique 10-digit message ID
    private String generateMessageID() {
        return String.format("%010d", new Random().nextInt(1000000000));
    }

    // Method 1: Ensure ID is 10 digits
    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    // Method 2: Ensure recipient number starts with + and has <=10 digits after that
    public int checkRecipientCell() {
        if (recipient.startsWith("+") && recipient.length() <= 13) {
            return 1;
        }
        return -1;
    }

    // Method 3: Create message hash in format: XX:YY:FirstWordLastWord
    public String createMessageHash() {
        String[] words = message.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        return (messageID.substring(0, 2) + ":" + messageCounter + ":" + firstWord + lastWord).toUpperCase();
    }

    // Method 4: Handle message actions
    public String SentMessage() {
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(null, "Choose an action:", "Message Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        if (choice == 0) {
            sentMessages.add(this);
            messageCounter++;
            return "Message sent";
        } else if (choice == 2) {
            storeMessage();
            return "Message stored";
        }
        return "Message disregarded";
    }

    // Method 5: Print message details
    public String printMessages() {
        return "Message ID: " + messageID +
               "\nMessage Hash: " + messageHash +
               "\nRecipient: " + recipient +
               "\nMessage: " + message;
    }

    // Method 6: Return total sent
    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    // Method 7: Store message in JSON
    public void storeMessage() {
        JSONObject obj = new JSONObject();
        obj.put("MessageID", messageID);
        obj.put("Recipient", recipient);
        obj.put("Message", message);
        obj.put("MessageHash", messageHash);
        storedMessages.add(obj);

        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(storedMessages.toJSONString());
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message to file.");
        }
    }

    // Accessor to get all sent messages
    public static List<Chat2> getSentMessages() {
        return sentMessages;
    }
}
