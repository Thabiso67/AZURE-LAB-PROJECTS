/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inheritance;

import java.util.ArrayList;

/**
 *
 * @author lab_services_student
 */
public class Inheritance {
    public static void main(String[] args) {
        Animal a1 = new Dog("Rex", 2, true);
        Animal a2 = new Animal("Skye", 3);
        Dog a3 = new Dog("Rex", 2, true);

        System.out.println(a1.getName() + " is an animal? " + (a1 instanceof Animal));

        // Test overridden methods
        System.out.println(a1.getName() + " likes to " + a1.move());
        System.out.println(a1.getName() + " says " + a1.speak());

        System.out.println(a2.getName() + " likes to " + a2.move());
        System.out.println(a2.getName() + " says " + a2.speak());

        // Update using the setters
        a3.setAge(10);
        System.out.println(a3.describe());

        // ------------------------------
        // Q4: Polymorphism demo
        // ------------------------------
        var zoo = new ArrayList<Animal>();
        zoo.add(new Animal("Skye", 3));
        zoo.add(new Dog("Rex", 2, true));
        zoo.add(new Cat("Mittens", 4));
        zoo.add(new Bird("Chirpy", 1, 2.5));

        System.out.println("\n--- Zoo Demo (Polymorphism) ---");
        for (Animal a : zoo) {
            System.out.println(a.getName() + " -> " + a.move() + " / " + a.speak());
        }

        // ------------------------------
        // Q5: Info hiding demo
        // ------------------------------
        Bird b = new Bird("Sky", 2, 1.8);
        System.out.println("\nBefore ageUp: " + b.getAge());
        ageUp(b, 3);
        System.out.println("After ageUp: " + b.getAge());
    }

    // Q5 helper method (uses getters/setters only)
    public static void ageUp(Animal a, int years) {
        a.setAge(a.getAge() + years);
    }
}
