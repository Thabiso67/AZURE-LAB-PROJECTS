/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.seriesapp.SeriesApp;
import com.mycompany.seriesapp.SeriesModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */

public class AppTestingIT {

    private SeriesApp app;

    @BeforeEach
    public void setUp() {
        app = new SeriesApp();
        // Seed with one known series
        app.addSeries(new SeriesModel("22", "Wednsday", "16", "12"));
    }

    // TestSearchSeries(): correct series returned
    @Test
    public void TestSearchSeries() {
        SeriesModel found = app.searchSeriesById("1");
        assertNotNull(found);
        assertEquals("Wednsday", found.SeriesName);
        assertEquals("16", found.SeriesAge);
        assertEquals("12", found.SeriesNumberOfEpisodes);
    }

    // TestSearchSeries_SeriesNotFound(): no series
    @Test
    public void TestSearchSeries_SeriesNotFound() {
        SeriesModel found = app.searchSeriesById("999");
        assertNull(found);
    }

    // TestUpdateSeries(): series successfully updated
    @Test
    public void TestUpdateSeries() {
        boolean updated = app.updateSeries("22", "House", "13", "177");
        assertTrue(updated);

        SeriesModel found = app.searchSeriesById("1");
        assertNotNull(found);
        assertEquals("House", found.SeriesName);
        assertEquals("13", found.SeriesAge);
        assertEquals("177", found.SeriesNumberOfEpisodes);
    }

    // TestDeleteSeries(): series successfully deleted
    @Test
    public void TestDeleteSeries() {
        boolean deleted = app.deleteSeries("1");
        assertTrue(deleted);
        assertNull(app.searchSeriesById("1"));
    }

    // TestDeleteSeries_SeriesNotFound(): deletion fails
    @Test
    public void TestDeleteSeries_SeriesNotFound() {
        boolean deleted = app.deleteSeries("999");
        assertFalse(deleted);
    }

    // TestSeriesAgeRestriction_AgeValid(): valid age
    @Test
    public void TestSeriesAgeRestriction_AgeValid() {
        assertTrue(app.isValidAgeRestriction("12"));
        assertTrue(app.isValidAgeRestriction("2"));
        assertTrue(app.isValidAgeRestriction("16"));
    }

    // TestSeriesAgeRestriction_SeriesAgeInValid(): invalid age
    @Test
    public void TestSeriesAgeRestriction_SeriesAgeInValid() {
        assertFalse(app.isValidAgeRestriction("1"));   // too low
        assertFalse(app.isValidAgeRestriction("19"));  // too high
        assertFalse(app.isValidAgeRestriction("abc")); // non-numeric
        assertFalse(app.isValidAgeRestriction(""));    // empty
        assertFalse(app.isValidAgeRestriction(null));  // null
    }
}