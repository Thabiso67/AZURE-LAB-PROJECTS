/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methoddoubleparameter;

/**
 *
 * @author lab_services_student
 */
public class MethodDoubleParameter {
    
    //Method that takes doubles and return their  product
    public static double productNumbers(double number01,double number02){
        return number01*number02;
        
    }
    public static void main(String[] args) {
        double num1 = 5.5;
        double num2 = 10.2;
        
        
        //calling the method and storing the result
        double product = productNumbers(num1,num2);
        System.out.println("The product of the two numbers is: "+product);
    }
}
