/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.pastexam2024q1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */

public class PastExam2024Q1Test {

    @Test
    public void testTotalMovieSales() {
        MovieTickets movieTickets = new MovieTickets();
        int[] napoleonSales = {3000, 1500, 1700};

        int total = movieTickets.TotalMovieSales(napoleonSales);

        // Expected total = 3000 + 1500 + 1700 = 6200
        assertEquals(6200, total, "Total sales for Napoleon should be 6200");
    }

    @Test
    public void testTopMovie() {
        MovieTickets movieTickets = new MovieTickets();
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300};

        String result = movieTickets.TopMovie(movies, totalSales);

        // Expected: Oppenheimer has the highest total
        assertTrue(result.contains("Oppenheimer"), "Top movie should be Oppenheimer");
        assertTrue(result.contains("6300"), "Top movie should have 6300 sales");
    }
}
