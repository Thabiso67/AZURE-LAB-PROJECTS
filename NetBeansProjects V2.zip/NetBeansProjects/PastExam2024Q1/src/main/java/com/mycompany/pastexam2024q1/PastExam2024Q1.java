/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pastexam2024q1;

/**
 *
 * @author lab_services_student
 */
public class PastExam2024Q1 {

    public static void main(String[] args) {
        // Movie names (Single-dimensional array)
        String[] movies = {"Napoleon", "Oppenheimer"};
        
        // Ticket sales for each movie across January, February, March (Two-dimensional array)
        int[][] sales = {
            {3000, 1500, 1700},   // Napoleon
            {3500, 1200, 1600}    // Oppenheimer
        };
        
        // Months for display
        String[] months = {"January", "February", "March"};
        
        // Display header
        System.out.println("====== CINEMA TICKET SALES REPORT (2024) ======");
        System.out.printf("%-15s %-10s %-10s %-10s %-10s%n", "Movie", "JAN", "FEB", "MAR", "TOTAL");
        System.out.println("--------------------------------------------------");
        
        int[] totalSales = new int[movies.length];
        int topIndex = 0; // To track the top-performing movie
        
        // Calculate total sales for each movie
        for (int i = 0; i < movies.length; i++) {
            int total = 0;
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
            totalSales[i] = total;
            
            // Display the row for each movie
            System.out.printf("%-15s %-10d %-10d %-10d %-10d%n",
                movies[i], sales[i][0], sales[i][1], sales[i][2], total);
            
            // Check for top performer
            if (totalSales[i] > totalSales[topIndex]) {
                topIndex = i;
            }
        }
        
        System.out.println("--------------------------------------------------");
        System.out.println("Top Performing Movie: " + movies[topIndex] + " with " + totalSales[topIndex] + " tickets sold.");
    }
}