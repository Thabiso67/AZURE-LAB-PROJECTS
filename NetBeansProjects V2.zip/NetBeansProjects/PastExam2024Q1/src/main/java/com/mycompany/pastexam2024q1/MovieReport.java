/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pastexam2024q1;

/**
 *
 * @author lab_services_student
 */
    public class MovieReport {
    public static void main(String[] args) {
        // Movie names
        String[] movies = {"Napoleon", "Oppenheimer"};

        // Ticket sales for Jan, Feb, Mar (2D array)
        int[][] sales = {
            {3000, 1500, 1700},   // Napoleon
            {3500, 1200, 1600}    // Oppenheimer
        };

        // Create an object of MovieTickets
        MovieTickets movieTickets = new MovieTickets();

        // Store total sales per movie
        int[] totalSales = new int[movies.length];

        System.out.println("====== CINEMA TICKET SALES REPORT (2024) ======");
        System.out.printf("%-15s %-10s %-10s %-10s %-10s%n", "Movie", "JAN", "FEB", "MAR", "TOTAL");
        System.out.println("--------------------------------------------------");

        // Calculate and display totals
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = movieTickets.TotalMovieSales(sales[i]);
            System.out.printf("%-15s %-10d %-10d %-10d %-10d%n",
                movies[i], sales[i][0], sales[i][1], sales[i][2], totalSales[i]);
        }
        
        System.out.println("--------------------------------------------------");
        System.out.println("Top Performing Movie: " + movieTickets.TopMovie(movies, totalSales));
    }
}