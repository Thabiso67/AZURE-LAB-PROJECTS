/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sacricketapplication;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class SACricketApplication {

    public static void main(String[] args) {
        
        String[] Stadiums = {"Kingsmead", "ST Georges", "Wanderers"};

        String[] Batsmen = {"Jaques Kallis", "Hashim Amla", "AB de Villiers"};
        
       Scanner sc = new Scanner(System.in);
       
       int [][] runs = populateStadium(Stadiums, Batsmen, sc);
       
        
       int [] stadiumTotals = calculateStadiumTotals(Stadiums, Batsmen, runs);
        
       
        String highStadium = getHighStadium(Stadiums, stadiumTotals);
       
        
        printReport(runs, stadiumTotals, highStadium, Stadiums);
        
    }
    
    public static int[][] populateStadium(String[] Stadiums, String [] Batsmen, Scanner sc) {
   
        int [][] runs = new int[Stadiums.length][Batsmen.length];
        for (int stadium = 0; stadium < Stadiums.length; stadium ++) {
            
            for (int v = 0; v < runs.length; v++) {
                
                runs[stadium][v] = readNonNegativeInt(
                        sc,
                        "  Enter number of " + Arrays.toString(runs[v]) + " runs in " + Stadiums[stadium] + ": "
                );
                
            }
            
        }
        return runs;
    }
    
    public static int[] calculateStadiumTotals (String[] Stadiums, String [] Batsmen, int[][] runs){
         int[] stadiumTotals = new int[Stadiums.length];
         
          for (int stadium = 0; stadium < Stadiums.length; stadium++) {
            int sumForStadium = 0; 
            for (int v = 0; v < Batsmen.length; v++) {
                
                sumForStadium += runs[stadium][v]; 
            }
            stadiumTotals[stadium] = sumForStadium; 
        }
        return stadiumTotals; 
    }
    
    public static String getHighStadium (String [] Stadiums, int [] stadiumTotals){
                
        int maxStadiumIndex = 0;
        for (int i = 1; i < stadiumTotals.length; i++) {
            if (stadiumTotals[i] > stadiumTotals[maxStadiumIndex]) {
                maxStadiumIndex = i;
            }
        }
        
        
        String highStadium = Stadiums[maxStadiumIndex];
        
        return highStadium;
    }
    
    
 
    private static int readNonNegativeInt(Scanner sc, String prompt) {
        System.out.println(prompt);
        int val = 0;
        if ( sc.hasNext() ) {
            val = sc.nextInt();
            return val;
        } else {
            System.out.println("Please enter a number");
            sc.next();
        }
        return 0;
    }
    
    private static void printReport (int [][] runs, int[] stadiumTotals, String highStadium, String [] Stadiums) {
        
        System.out.println("------------------------------------------------------");
        System.out.println("Runs Scored Report");
        System.out.println("------------------------------------------------------");
        
        System.out.printf("%-15s %10s %12s %10s%n", " ", "Jaques Kallis", "Hashim Amla","AB de Villiers", "Total");

        
        for (int stadium = 0; stadium < Stadiums.length; stadium++) {
            int Kallis = runs[stadium][0];
            int HashimAmla = runs[stadium][1];
            int Villiers = runs[stadium][2];
            int total = stadiumTotals[stadium];

            System.out.printf("%-15s %10d %12d %10d%n", Stadiums[stadium], Kallis, HashimAmla, Villiers, total);
        }
        
        System.out.println("------------------------------------------------------");
        System.out.println("TOTAL RUNS AT EACH CITY");
        System.out.println("------------------------------------------------------");
        
        for ( int stadium = 0; stadium < Stadiums.length; stadium ++ ) {
            System.out.println(Stadiums[stadium] +" : " + stadiumTotals[stadium] );
        }
        
        System.out.println("STADIUM WITH THE MOST RUNS : " + highStadium);
        
        
    }
}