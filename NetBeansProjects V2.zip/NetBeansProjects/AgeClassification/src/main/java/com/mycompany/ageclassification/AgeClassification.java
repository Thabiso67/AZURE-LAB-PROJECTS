/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ageclassification;

/**
 *
 * @author lab_services_student
 */
public class AgeClassification {

    public static void main(String[] args) {
        int Age = 18; 
        
        if (Age > 18) {
            
            System.out.println("You are an adult");
            
        }else{
            
            System.out.println("You are under the age of 18");
    }
}

}