/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pastexam2023q2;

/**
 *
 * @author lab_services_student
 */
public class PastExam2023Q2 {

    public static void main(String[] args) {
       int [][] propertySaler = ((800000,150000,2000000),
                   (700000,1200000, 1600000));
        
    }
}
