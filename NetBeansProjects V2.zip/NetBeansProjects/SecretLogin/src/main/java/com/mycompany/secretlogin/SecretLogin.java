/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.secretlogin;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class SecretLogin {

    public static void main(String[] args) {
        final String SECRET = "TOP_SECRET";
        
        String input = JOptionPane.showInputDialog("Enter secret access code:");
        
        if (input.equals(SECRET)) {
            JOptionPane.showMessageDialog(null, "Acess granted.");
        }else{ 
            JOptionPane.showMessageDialog(null, "Incorrect code.");
        }
    }
}
