/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simpledictionarytwo;

import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class SimpleDictionaryTwo {

    public static void main(String[] args) {
        // Create a dictionary  using (HashMap)
        HashMap<String, String> dictionary = new HashMap<>();
        
        //Add some and their meanings 
        dictionary.put("apple", "A fruit that is red or green and grows on trees");
        dictionary.put("java", "A high level programming language");
        dictionary.put("computer", "An electronic device for storing and processing");
        
        //Take user input
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a word to look up its meaning:");
        String word = scanner.nextLine().toLowerCase();
        
        //Look up the word
        if (dictionary.containsKey(word)) {
            System.out.println("Mean:"+dictionary.get(word));
        }else{
            System.out.println("word not found in the dictionary");
        }
        
    }
}
