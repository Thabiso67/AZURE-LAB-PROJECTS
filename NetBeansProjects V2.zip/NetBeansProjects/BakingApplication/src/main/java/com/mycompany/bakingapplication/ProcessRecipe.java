/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bakingapplication;

/**
 *
 * @author lab_services_student
 */
// Subclass
class ProcessRecipe extends Recipes {

    // Constructor
    public ProcessRecipe(String ingredients, int timeToMake, String difficultyLevel) {
        super(ingredients, timeToMake, difficultyLevel);
    }

    // Implement PrintRecipes method
    @Override
    public void PrintRecipes() {
        System.out.println("Recipe Details:");
        System.out.println("------------------------");
        System.out.println("Ingredients: " + getIngredients());
        System.out.println("Time to Make: " + getTimeToMake() + " minutes");
        System.out.println("Difficulty Level: " + getDifficultyLevel());
        System.out.println();
    }
}