/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bakingapplication;

/**
 *
 * @author lab_services_student
 */
// BakingApplication.java
public class BakingApplication {
    public static void main(String[] args) {
        // Instantiate ProcessRecipe objects
        ProcessRecipe recipe1 = new ProcessRecipe(
                "Flour, Sugar, Eggs, Butter, Baking Powder", 
                45, 
                "Medium"
        );

        ProcessRecipe recipe2 = new ProcessRecipe(
                "Chocolate, Flour, Sugar, Eggs, Butter", 
                60, 
                "Hard"
        );

        // Print the recipes
        recipe1.PrintRecipes();
        recipe2.PrintRecipes();
    }
}
