/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bakingapplication;

/**
 *
 * @author lab_services_student
 */

// Abstract class
abstract class Recipes implements iRecipes {
    // Variables to store recipe details
    private String ingredients;
    private int timeToMake; // in minutes
    private String difficultyLevel;

    // Constructor
    public Recipes(String ingredients, int timeToMake, String difficultyLevel) {
        this.ingredients = ingredients;
        this.timeToMake = timeToMake;
        this.difficultyLevel = difficultyLevel;
    }

    // Get methods
    public String getIngredients() {
        return ingredients;
    }

    public int getTimeToMake() {
        return timeToMake;
    }

    public String getDifficultyLevel() {
        return difficultyLevel;
    }
}
