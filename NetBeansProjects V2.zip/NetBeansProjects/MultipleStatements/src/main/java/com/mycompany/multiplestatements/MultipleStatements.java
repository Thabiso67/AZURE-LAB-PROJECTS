/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multiplestatements;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class MultipleStatements {
    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        int x = 10;
        int y = 5;
        //If-else block with multiple statements
        if(x>y){
        //Multiple statements inside the block
        System.out.println("x is greater than y");
        scanner.nextLine();
        int sum = x+y;
        System.out.println("Sum of and y"+sum);
        scanner.nextLine();
        System.out.println("Difference between x and y: "+(x-y));
        }else {
            //Multiple Statements in the else block
           System.out.println("x is not greater than y");
           int product =x*y;
           System.out.println("Product of than y: "+product);
           System.out.println("Quotient of x divided by y: "+(x/y));
        }
    }
}
