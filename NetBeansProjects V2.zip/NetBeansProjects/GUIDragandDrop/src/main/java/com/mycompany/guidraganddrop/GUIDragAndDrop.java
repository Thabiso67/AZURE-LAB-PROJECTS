/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guidraganddrop;

/**
 *
 * @author lab_services_student
 */
public class GUIDragAndDrop {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
