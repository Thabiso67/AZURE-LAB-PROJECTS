/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pastexam2023q1v2;

/**
 *
 * @author lab_services_student
 */

public class PastExam2023Q1V2 {
    public static void main(String[] args) {
        int[][] propertySales = {
            {800000, 1500000, 2000000},
            {700000, 1200000, 1600000}
        };

        String[] agent = {"Joe Bloggs", "Jane Doe"};
        String[] months = {"Jan", "Feb", "Mar"};

        System.out.println("Estate Agent Report");
        System.out.println("\t\t" + months[0] + "\t" + months[1] + "\t" + months[2]);
        System.out.println("------------------------------------------------------");

        for (int i = 0; i < agent.length; i++) {
            System.out.print(agent[i] + "\t");
            for (int j = 0; j < months.length; j++) {
                System.out.print("\t" + propertySales[i][j]);
            }
            System.out.println();
        }

        // Calculate totals
        double[] totals = new double[propertySales.length];
        for (int i = 0; i < propertySales.length; i++) {
            double total = 0;
            for (int j = 0; j < propertySales[i].length; j++) {
                total += propertySales[i][j];
            }
            totals[i] = total;
        }

        // Print totals
        for (int i = 0; i < totals.length; i++) {
            System.out.println("Total property sales for " + agent[i] + " = R" + totals[i]);
        }

        // Calculate commissions
        double[] commission = new double[totals.length];
        for (int i = 0; i < totals.length; i++) {
            commission[i] = totals[i] * 0.02;
        }

        // Print commissions
        for (int i = 0; i < commission.length; i++) {
            System.out.println("Commission for " + agent[i] + " = R" + commission[i]);
        }

        // Top performing agent
        int indexTopPerforming = 0;
        double valueTopPerforming = totals[0];
        for (int i = 1; i < totals.length; i++) {
            if (totals[i] > valueTopPerforming) {
                valueTopPerforming = totals[i];
                indexTopPerforming = i;
            }
        }

        System.out.println("\nTop-performing agent: " + agent[indexTopPerforming] +
                           " with total sales of R" + valueTopPerforming);
    }
}