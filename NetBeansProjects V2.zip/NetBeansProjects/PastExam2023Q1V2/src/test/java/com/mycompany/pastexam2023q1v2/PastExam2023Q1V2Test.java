/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.pastexam2023q1v2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class PastExam2023Q1V2Test implements IEstateAgent {

    @Override
    public double EstateAgentSales(double[] propertySales) {
        double total = 0;
        for (double sale : propertySales) {
            total += sale;
        }
        return total;
    }

    @Override
    public double EstateAgentCommission(double totalSales) {
        return totalSales * 0.02;
    }

    @Override
    public int TopEstateAgent(double[] totalSales) {
        int topIndex = 0;
        double topValue = totalSales[0];

        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > topValue) {
                topValue = totalSales[i];
                topIndex = i;
            }
        }
        return topIndex;
    }
}
