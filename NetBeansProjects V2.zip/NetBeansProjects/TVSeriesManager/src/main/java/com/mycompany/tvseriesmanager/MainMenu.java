/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tvseriesmanager;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class MainMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Series TVSeriesManager = new Series(scanner);

        while (true) {
            System.out.println("\n===== TV Series Manager =====");
            System.out.println("1. Capture a new series");
            System.out.println("2. Search for a series");
            System.out.println("3. Update a series");
            System.out.println("4. Delete a series");
            System.out.println("5. View series report");
            System.out.println("6. Exit");
            System.out.print("Choose an option (1-6): ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> TVSeriesManager.CaptureSeries();
                case "2" -> TVSeriesManager.SearchSeries();
                case "3" -> TVSeriesManager.UpdateSeries();
                case "4" -> TVSeriesManager.DeleteSeries();
                case "5" -> TVSeriesManager.SeriesReport();
                case "6" -> {
                    TVSeriesManager.ExitSeriesApplication(); return;
                }
                default -> System.out.println("Invalid option. Try 1-6.");
            }
        }
    }
}