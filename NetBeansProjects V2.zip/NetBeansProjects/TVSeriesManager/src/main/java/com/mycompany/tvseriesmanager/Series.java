/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tvseriesmanager;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
class Series {
    private final ArrayList<TVSeriesManager> seriesList = new ArrayList<>();
    private final Scanner scanner;

    public Series(Scanner scanner) {
        this.scanner = scanner;
    }

    // 1) Capture a new series
    public void CaptureSeries() {
        System.out.println("\n=== Capture New Series ===");

        System.out.print("Enter Series ID: ");
        String id = scanner.nextLine().trim();

        System.out.print("Enter Series Name: ");
        String name = scanner.nextLine().trim();

        String age;
        while (true) {
            System.out.print("Enter Age Restriction (2-18): ");
            age = scanner.nextLine().trim();

            if (!isNumeric(age)) {
                System.out.println("Invalid: age must be a NUMBER. Try again.");
                continue;
            }
            int a = Integer.parseInt(age);
            if (a < 2 || a > 18) {
                System.out.println("Invalid: age must be between 2 and 18. Try again.");
                continue;
            }
            break;
        }

        String episodes;
        while (true) {
            System.out.print("Enter Number of Episodes: ");
            episodes = scanner.nextLine().trim();

            if (!isNumeric(episodes)) {
                System.out.println("Invalid: episodes must be a NUMBER. Try again.");
                continue;
            }
            break;
        }

        seriesList.add(new TVSeriesManager(id, name, age, episodes));
        System.out.println("Series details saved successfully.");
    }

    // 2) Search
    public void SearchSeries() {
        System.out.print("\nEnter Series ID to search: ");
        String id = scanner.nextLine().trim();
        TVSeriesManager s = getById(id);
        if (s != null) {
            System.out.println("Found: " + s);
        } else {
            System.out.println("No series data could be found for ID: " + id);
        }
    }

    // 3) Update
    public void UpdateSeries() {
        System.out.print("\nEnter Series ID to update: ");
        String id = scanner.nextLine().trim();
        TVSeriesManager s = getById(id);
        if (s == null) {
            System.out.println("Series not found.");
            return;
        }

        System.out.println("Leave a field blank to keep it unchanged.");

        System.out.print("New Series Name (" + s.SeriesName + "): ");
        String newName = scanner.nextLine().trim();
        if (!newName.isEmpty()) s.SeriesName = newName;

        while (true) {
            System.out.print("New Age Restriction (" + s.SeriesAge + "): ");
            String newAge = scanner.nextLine().trim();
            if (newAge.isEmpty()) break;
            if (!isAgeValid(newAge)) {
                System.out.println("Invalid age. Must be a NUMBER between 2 and 18.");
                continue;
            }
            s.SeriesAge = newAge;
            break;
        }

        while (true) {
            System.out.print("New Number of Episodes (" + s.SeriesNumberOfEpisodes + "): ");
            String newEp = scanner.nextLine().trim();
            if (newEp.isEmpty()) break;
            if (!isNumeric(newEp)) {
                System.out.println("Invalid: must be a NUMBER.");
                continue;
            }
            s.SeriesNumberOfEpisodes = newEp;
            break;
        }

        System.out.println("Series updated successfully.");
    }

    // 4) Delete
    public void DeleteSeries() {
        System.out.print("\nEnter Series ID to delete: ");
        String id = scanner.nextLine().trim();
        TVSeriesManager s = getById(id);
        if (s == null) {
            System.out.println("Series not found.");
            return;
        }

        System.out.print("Are you sure you want to delete \"" + s.SeriesName + "\" (y/n)? ");
        String confirm = scanner.nextLine().trim().toLowerCase();
        if (confirm.equals("y") || confirm.equals("yes")) {
            seriesList.remove(s);
            System.out.println("Series deleted.");
        } else {
            System.out.println("Delete cancelled.");
        }
    }

    // 5) Report
    public void SeriesReport() {
        System.out.println("\n=== Series Report ===");
        if (seriesList.isEmpty()) {
            System.out.println("(No series captured)");
            return;
        }
        System.out.printf("%-10s %-25s %-5s %-10s%n", "ID", "Name", "Age", "Episodes");
        for (TVSeriesManager s : seriesList) {
            System.out.printf("%-10s %-25s %-5s %-10s%n",
                    s.SeriesId, s.SeriesName, s.SeriesAge, s.SeriesNumberOfEpisodes);
        }
    }

    // 6) Exit
    public void ExitSeriesApplication() {
        System.out.println("Exiting... Bye!");
    }

    // Helper methods
    TVSeriesManager getById(String id) {
        for (TVSeriesManager s : seriesList) {
            if (s.SeriesId.equalsIgnoreCase(id)) return s;
        }
        return null;
    }

    static boolean isNumeric(String s) {
        if (s == null || s.isEmpty()) return false;
        for (char c : s.toCharArray()) if (!Character.isDigit(c)) return false;
        return true;
    }

    boolean isAgeValid(String age) {
        if (!isNumeric(age)) return false;
        int a = Integer.parseInt(age);
        return a >= 2 && a <= 18;
    }
}