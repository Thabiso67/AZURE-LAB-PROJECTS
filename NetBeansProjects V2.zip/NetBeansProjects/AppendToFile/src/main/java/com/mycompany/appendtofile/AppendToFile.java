/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.appendtofile;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class AppendToFile {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String fileName = "text.txt"; //File must be in project folder
        
        System.out.println("Enter text to append to 'text.txt' (type 'exit' to finish):");
        
        try (FileWriter writer = new FileWriter(fileName, true)) { // 'true' enables append mode
            while (true) {
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("exit")) {
                    break;
                }
                writer.write(input + System.lineSeparator());
            }
            System.out.println("Text successfully appended to 'text.txt'.");
        } catch (IOException e) {
            System.out.println("Error writing to file.");
            e.printStackTrace();
        }
        scanner.close();
    }
}
