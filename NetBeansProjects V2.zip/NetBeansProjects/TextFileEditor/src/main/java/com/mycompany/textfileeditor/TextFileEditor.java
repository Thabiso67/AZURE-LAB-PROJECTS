/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.textfileeditor;

import java.io.*;
import java.util.*;

/**
 *
 * @author lab_services_student
 */
public class TextFileEditor {

    public static void main(String[] args) {
        String filePath = "example.txt"; //Your file patch here
        String wordToRemove = "deleteMe"; //Word or pharse to remove
        
        try{
            File inputFile = new File(filePath);
            File tempFile = new File("temp.txt");
            
            Scanner scanner = new Scanner(inputFile);
            PrintWriter writer = new PrintWriter(new FileWriter(tempFile));
            
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                // Skip lines that contain the wordToRemove
                if (!line.contains(wordToRemove))
                    writer.println(line);
            }
        }
        
        
        scanner.close();
        writer.close();
        
        //Replace original file with the update temp
        if (inputFile.delete()) {
            tempFile.renameTo(inputFile);
            System.out.println("Updated file succsessfully.");
        } else {
            System.out.println("Could not delete original file.");
        }
        
        
    } catch (IOException e) {
         e.printStackTrace();
         
}
}
}

