/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simplelogin;

/**
 *
 * @author lab_services_student
 */
public class SimpleLogin {

    public static void main(String[] args) {
        String usersname = 
    }
}
