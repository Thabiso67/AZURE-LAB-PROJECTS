/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pastexam2023q1;

/**
 *
 * @author lab_services_student
 */
public class PastExam2023Q1 {

    public static void main(String[] args) {
         int [][] propertySales = ((800000,150000,2000000),
                   (700000,1200000, 1600000));
         
         String[] agent = ("Joe Bloggs", "Jane Doe");
         String[] months = ("Jan", "Feb", "Mar");
         
         System.out.println("Estate Agent Report");
         System.out.println("\t\t" + months[0] +"\t" + months[1] +"\t" +months[2]);
         System.out.println("--------------------------------------------------------");
         
         for (int i = 0; i <agent.length; i ++) {
             System.out.print (agent[i]);
             for (int j = 0; j < months.length; j ++) {
                 System.out.print("\t" +  propertySales[i][j]);
             }
             System.out.println("");
            
         }
         
         //double [] totals =  new double[agent.length];
         //stores totals per row
          double [] totals =  new double[propertySales.length]; //both ways work
          
          //propertySales[0].length gives the number of columns
          //calculate totals
          for (int i = 0; i < propertySales.length; i ++) {
              //totals hold the total per row
              double total = 0;
          for (int j = 0; j < propertySales.length; j ++) {    
              total = total + propertySales[i][j];
          }
          totals[i] = total;
    }
          //print totals
          for(int i = 0; i < totals.length; i ++) {
              System.out.println("The total property sales for" + agent[i] + "= R" +totals[i]);
          }
          
          //Calculate commision earned
          double[] commission = new double(totals.length);
          for  (int i = 0; i < totals.length; i++);
                double com = totals[i] + 0.02;
                commission[i] = com;
          
    }
    
          //print the commission
          for(int i = 0; i < commission.length; i ++ ) {
              System.out.println("Sale comission for " + agent[i] + " = R" + comission[i] );
    }
          
          
          //calculate top perform agent
          int indexTopPerforming =0;
          double valueTopPerforming = 0;
          for()
}