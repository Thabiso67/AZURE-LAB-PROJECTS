/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.prog6112examq1;

/**
 *
 * @author lab_services_student
 */
public interface IProductSales {
    
    int TotalSales(int[][]productSales);
    double AverageSales(int[][]productSales);
    int MaxSale(int[][] productSales);
}