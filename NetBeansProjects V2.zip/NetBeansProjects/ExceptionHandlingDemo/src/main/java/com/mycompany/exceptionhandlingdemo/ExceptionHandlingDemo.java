/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exceptionhandlingdemo;

/**
 *
 * @author lab_services_student
 */
public class ExceptionHandlingDemo {

    public static void main(String[] args) {
        System.out.println("Try_catch Demo");
       
        //handle a division by zero
        try {
            int result = 10/0;
            System.out.println("Result :" + result);
        }
        catch (ArithmeticException e) {
            //lets say we were accepting an input form from the user
            //and we needed an int and get a string
            //we can catch multiple different types of exceptions
            System.out.println("Error caught: Cannot divide by zero");
            System.out.println("Exception message : " + e.getMessage());
        }
        catch (Exception e) {
           
           
        }
        System.out.println("Program continues after exception");
       
       System.out.println("Finally block Demo");
       
       
        try {
             System.out.println("Opeining a resource (Database/File ...)");
             int [] numbers = {1,2,3};
              System.out.println("Access invalid index");
               System.out.println(numbers[5]);
                System.out.println("Doesn't get here");
        }
        catch (ArrayIndexOutOfBoundsException e) {
             System.out.println("Error : Index does  not exist");
        }
        finally {
             System.out.println("Closing resources...");
        }
       
         System.out.println("Using Methods that Throw Exceptions");
         try {
             int result1 = Divide(10,2);
              System.out.println("Result 10/2 : " + result1);
             
              int result2 = Divide(10,0);
              System.out.println("Result 10/0 : " + result2);
         }
         
         catch (Exception e) {
              System.out.println(e.getMessage());
         }
         
         System.out.println("Call Stack Demo");
         try {
             levelOne();
         }
         catch (Exception e){
             System.out.println("Exception caught in main");
             System.out.println("Error message :" + e.getMessage());
             System.out.println("Call Stack Trace: ");
             e.printStackTrace();
         }

       
    }
   
    public static void levelThree() throws Exception {
        System.out.println("Level 3: About to throw exception");
        throw new Exception();
    }
   
    public static void levelTwo() throws Exception {
        System.out.println("Level 2: About to cal level 3");
        levelThree();
    }
   
    public static void levelOne() throws Exception {
        System.out.println("Level 1: About to cal level 2");
        levelTwo();
    }
   
   
   
   
   
   
   
   
    public static int Divide(int x, int y) throws Exception {
        return x/y;
    }
}