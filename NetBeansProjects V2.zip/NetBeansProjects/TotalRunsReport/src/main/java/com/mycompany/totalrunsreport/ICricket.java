/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.totalrunsreport;

/**
 *
 * @author lab_services_student
 */
public interface ICricket {
    String getBatsmen();
    String getStadium();
    int getRunsScored();
}
