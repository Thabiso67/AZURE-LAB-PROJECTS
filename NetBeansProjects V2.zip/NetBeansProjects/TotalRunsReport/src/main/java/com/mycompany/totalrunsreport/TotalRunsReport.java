/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.totalrunsreport;

/**
 *
 * @author lab_services_student
 */
public class TotalRunsReport {

    public static void main(String[] args) {
 
    }