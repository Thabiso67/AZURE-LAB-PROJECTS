/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.switchordecisionstatement;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */

public class SwitchorDecisionStatement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final double BASIC_MEMBERSHIP = 350.00;
        final double SPECIALS = 450.00;
        final double VIP_TREATMENT = 550.00;

        boolean[] selected = new boolean[4]; // Indexes: 1, 2, 3 for options
        double total = 0;

        while (true) {
            // Display menu
            System.out.println("\nMenu:");
            System.out.println("1. Basic membership - R" + BASIC_MEMBERSHIP);
            System.out.println("2. Specials - R" + SPECIALS);
            System.out.println("3. VIP treatment - R" + VIP_TREATMENT);
            System.out.println("0. Exit");

            System.out.print("Enter your choice (1, 2, 3 or 0 to quit): ");

    }
}
}