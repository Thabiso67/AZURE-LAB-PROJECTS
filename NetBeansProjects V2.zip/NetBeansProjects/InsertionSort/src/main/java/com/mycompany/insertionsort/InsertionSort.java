/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.insertionsort;

/**
 *
 * @author lab_services_student
 *
*Think of it like a stack of cards (list of some object/primitive type) you are gives a single card at a time
*Starting form index 0, you want to find the correct position for card
*If the card is < the card (cardoorpare) we are compaing to shift card compared 1 position to the right
* Do this will you find that the condition you are testing no longer holds (card 1< cardcompare)
* You then add card to the position of card compare
* 
*/
public class InsertionSort {

    public static void main(String[] args) {
        
        int [] arr = {25, 3, 8, 11, 17, 6};
        
        for ( int i = 1; i < arr.length - 1; i++ ){
            
            int temp = arr[i];
            int j = i -1;
            
            while (j >=0 && arr[i]>arr[i]) {
                
                arr[j+i] = arr[j];
                //j--;
                
            }
            
                arr[j+i] = temp;
                }
                for ( int num : arr ) {
        
           
        System.out.println(num + ",");
        
                }
    }
}