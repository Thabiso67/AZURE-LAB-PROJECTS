/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methoduserinputsum;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class MethodUserInputSum {
        //Method to take two integers as an input
        public static int addTwoIntegers() {
                Scanner scanner = new Scanner(System.in);
  
        //Get the first Integer
        System.out.print("Enter your first integer: ");
        int num1 = scanner.nextInt();
        //Get the secon integer
        System.out.print("Enter your second Integer"); //Push to Git Hub
        int num2 = scanner.nextInt();
        // Return the sum of the two
        return num1+num2;}
        public static void main(String[] args) {
            //Call the method to add the Integer and display the result
            int sum = addTwoIntegers();
            System.out.println("The sum of the two numbers is: "+sum);
        }
}