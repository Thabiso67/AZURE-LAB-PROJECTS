/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numberdictionary;

import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class NumberDictionary {

    public static void main(String[] args) {
        //Allows for a reason
        Scanner scanner = new Scanner(System.in);
        //Allows us to be able to store values and keys on the dictionary and be able to retrieve it
        HashMap<String, Integer> dictionary = new HashMap<>();
        
        //Created count so that is can ask the user how many entries
        //The user would like to make to to create  the dictionary
        System.out.print("How many entries do you want to add");
        
        // We recieve our count(Number of entries from the user a string and convert to integer
        int count = Integer.parseInt(scanner.nextLine());
        
        //Input name-number pairs
        //Initializing our i=0 so that we can be able to do increment
        //for i if it is less then our number of entries we will increment(i=i+i)
        for (int i = 0; i < count; i++) {
            
        //We are asking the user to enter a name or key
        System.out.print("Enter name/key: ");
        String key = scanner.nextLine();
        //we are receiving our name or key to enter the user
         System.out.print("Enter Number/Value for '" + key + "': ");
        //We recieve the number or value as a string and then convert it into an Integer
        int value = Integer.parseInt(scanner.nextLine());
        //We then create our dictionary and specify how we want our key and Value  to be stored
        dictionary.put(key, value);
        //Display to the user the added  key and it correspondence added value
        System.out.println("Added : " + key + " => " + value + "\n");
        
        }
        
        //Lookup phase
        //we ask the user to enter a name or key so we can display the corresponding Value
        System.out.print("Enter a name/key to get its number  ");
        //we recive that Name or key as a string and store it on searchKey variable
        String searchKey = scanner.nextLine();
        // If  the dictionary that we created previously has the Name or Key that we are searching for
        if (dictionary.containsKey(searchKey)) {
            //Retrieve the value for the search key and display it
            System.out.println("Value for '" + searchKey + "':" + dictionary.get(searchKey));
        }else{
            //if the dictionary does not have the search key display key not found
            System.out.println("Key not found in the dictionary.");
        }
        
        //close the Scanner
        scanner.close();
    }
}
