/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guidemo;

/**
 *
 * @author lab_services_student
 */
public class GUIDemo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
