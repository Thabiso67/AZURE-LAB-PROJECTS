/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.pastexam2024q2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class PastExam2024Q2Test {
    

    @Test
    public void CalculateTotalTicketPrice_CalculatedSuccessfully() {
        MovieTickets movieTickets = new MovieTickets();
        double result = movieTickets.CalculateTotalTicketPrice(3, 100.0);
        assertEquals(300.0, result, 0.001);
    }

    @Test
    public void Validation_Fails_For_InvalidData() {
        MovieTickets movieTickets = new MovieTickets();
        MovieTicketData invalidData = new MovieTicketData("", -2, -100.0);
        assertFalse(movieTickets.ValidateData(invalidData));
    }
}
