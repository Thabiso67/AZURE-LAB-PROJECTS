/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pastexam2024q2;

/**
 *
 * @author lab_services_student
 */
public class PastExam2024Q2 {

   
}
