/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.twodimensionalarrays;

/**
 *
 * @author lab_services_student
 */
public class TwoDimensionalArrays {

    public static void main(String[] args) {
        //declare a empty 2D array
        //declare a populating 2D array (Hint : 1D = (1,2,3)
        //move / traverse through the empty array and populate with same value
        //create a method that prints an array format =>     1. 2 <= first row
        //                                                   3. 4 <= second row
        // call print method and pass an array to that method
        
         int [] [] emptyArray = new int [2] [5];
         int [] [] populateArray = {
             {1,2,3},
             {4,5,6}
             
         };
         
        //Breadth first traversal
        //move through the costs the cols of a row before you move down a row
        
        
        for ( int i = 0; i < emptyArray.length - 1; i++ ) {
            for ( int j = 0; j < emptyArray[0].length -1; j++ ) {
                emptyArray[i][j] =1;
                
                
            }
        }
    
    printArray(populateArray);
    System.out.print("--------");
    printArray(emptyArray);
    
    //get the totals of each row
    for ( int row = 0; row < populate )
    
    }
                
                public static void printArray ( int [][] arr ){
                    
                    for ( int i = 0; i < arr.length ; i++) {
                        for (int j = 0; j < arr[0].length ; j++) {
                System.out.print(arr[i][j] + ",");
            }
             System.out.println("\n");
        }
        
    }
}