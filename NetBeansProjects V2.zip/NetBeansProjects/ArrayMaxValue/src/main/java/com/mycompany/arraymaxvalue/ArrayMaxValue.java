/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraymaxvalue;

import java.util.Arrays;

/**
 *
 * @author lab_services_student
 */
public class ArrayMaxValue {

    public static void main(String[] args) {
        int[] numbers = {45,78,12,34,89,23};
        int max = numbers[0];
        String result = Arrays.toString(numbers); //converting integer Array to Strings Array
        
        System.out.println("Converted Arrays: "+result); //result of the converted arrays
        
        
        for (int num:numbers){
            if (num>max){
                max=num;
            }
        }
        System.out.println("Maximum value is: "+max);
    }
}