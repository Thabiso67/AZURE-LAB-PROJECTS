/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guidemo2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author lab_services_student
 */
public class GUIDemo2 {

    public static void main(String[] args) {
        
    }
    
    public static class MainWindow extends JFrame implements ActionListener {
        
    private JLabel titleLable;
    private JLabel nameLable;
    private JLabel studentLable;
    private JLabel emailLable;
    private JLabel statusLable;
    
    private JTextField nameField;
    private JTextField studentField;
    private JTextField emailField;
    
    private JButton submitButton;
    private JButton clearButton;
    private JButton exitButton;
    
    private JPanel titlePanel;
    private JPanel inputPanel;
    private JPanel bottonPanel;
    private JPanel statusPanel;
    private JPanel mainPanel;
    
    public void initialiseComponents() {
    
    titleLabel = new JLabel("Student Registration", swingConstants.CENTER); 
    titleLabel.setFont (new font(("Times New Romans" , Font.BOLD,26)));
    titleLabel.setForeground(new Color (0,51,102)); 
        
    @Override
    public void actionPerformed (ActionEvent e) {
        
        
     }
    
    }
    
    }