/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hotelbookingapp;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */

/*
 * Hotel Booking App
 * This application manages hotel room reservations. Users can book, update,
 * cancel, and view bookings. It demonstrates arrays, inheritance,
 * constructors, and information hiding. Unit tests are included to confirm
 * that the booking process works as expected.
 */


class SingleRoom extends Room {
    public SingleRoom(int roomNumber) { super(roomNumber); }
}

class DoubleRoom extends Room {
    public DoubleRoom(int roomNumber) { super(roomNumber); }
}

class Suite extends Room {
    public Suite(int roomNumber) { super(roomNumber); }
}

public class HotelBookingApp {
    private static Room[] rooms = new Room[6]; // small hotel for demo

    public static void main(String[] args) {
        //Rooms available to book
        rooms[0] = new SingleRoom(101);
        rooms[1] = new SingleRoom(102);
        rooms[2] = new DoubleRoom(201);
        rooms[3] = new DoubleRoom(202);
        rooms[4] = new Suite(301);
        rooms[5] = new Suite(303);

        Scanner sc = new Scanner(System.in);
        int choice;

        //Features of the app
        do {
            System.out.println("\n=== Hotel Booking System ===");
            System.out.println("1. View all rooms");
            System.out.println("2. Book a room");
            System.out.println("3. Cancel booking");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> showReport();
                case 2 -> {
                    System.out.print("Enter room number to book: ");
                    int num = sc.nextInt();
                    bookRoom(num);
                }
                case 3 -> {
                    System.out.print("Enter room number to cancel: ");
                    int num = sc.nextInt();
                    cancelRoom(num);
                }
                case 4 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 4);
    }

    // View Booking report
    public static void showReport() {
        System.out.println("\n--- Hotel Report ---");
        for (Room r : rooms) {
            System.out.println(r);
        }
    }
    
    //Book a room
    public static void bookRoom(int roomNumber) {
        for (Room r : rooms) {
            if (r.getRoomNumber() == roomNumber) {
                if (!r.isBooked()) {
                    r.book();
                    System.out.println("Room " + roomNumber + " booked successfully!");
                } else {
                    System.out.println("Room already booked.");
                }
                return;
            }
        }
        System.out.println("Room not found.");
    }
    
    //Cancel the booking
    public static void cancelRoom(int roomNumber) {
        for (Room r : rooms) {
            if (r.getRoomNumber() == roomNumber) {
                if (r.isBooked()) {
                    r.cancel();
                    System.out.println("Room " + roomNumber + " booking cancelled!");
                } else {
                    System.out.println("Room was not booked.");
                }
                return;
            }
        }
        System.out.println("Room not found.");
    }
}
