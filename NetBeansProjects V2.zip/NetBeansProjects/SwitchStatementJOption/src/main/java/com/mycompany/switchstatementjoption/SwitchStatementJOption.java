/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.switchstatementjoption;
import javax.swing.JOptionPane;
/**
 *
 * @author lab_services_student
 */
public class SwitchStatementJOption {

    public static void main(String[] args) {
        
        
    String input1 = JOptionPane.showInputDialog(null,"Enter your First number");
    JOptionPane.showInputDialog(null,"Enter an operator (+,-,*,/): ");
    String input2 = JOptionPane.showInputDialog(null,"Enter your Second number");
    
    double num1 = Double.parseDouble(input1);
    char operator = operator.charAt(0);
    double num2 = Double.parseDouble(input2);
    
    
    switch(operator) {
             case'+':
                 JOptionPane.showMessageDialog(null,"Result: "+(num1+num2));
                 break;
             case'-':
                 JOptionPane.showMessageDialog(null,"Result: "+(num1+num2));
                 break;
             case'*':
                 JOptionPane.showMessageDialog(null,"Result: "+(num1+num2));
                 break;
             case'/':
                 if (num2!=0){
                 JOptionPane.showMessageDialog(null,"Result: "+(num1+num2));
                 }else{
                     JOptionPane.showMessageDialog(null,"Error: Cannot divide by zero.");
                     break;
    }
}
    }
}