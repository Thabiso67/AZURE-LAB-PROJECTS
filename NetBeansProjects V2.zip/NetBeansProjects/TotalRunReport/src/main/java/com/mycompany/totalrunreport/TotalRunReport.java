/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.totalrunreport;

/**
 *
 * @author lab_services_student
 */
public class TotalRunReport {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
