/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.testprep2021;

/**
 *
 * @author lab_services_student
 */
public class TestPrep2021 {
    public static void main(String[] args) {
        // 2D array: deliveries[year][month]
        int[][] deliveries = {
            {128, 135, 139}, // 2018
            {155, 129, 175}, // 2019
            {129, 130, 185}  // 2020
        };

        String[] years = {"2018", "2019", "2020"};
        String[] months = {"JAN", "FEB", "MAR"};

        int total = 0;
        int max = deliveries[0][0];
        int min = deliveries[0][0];

        System.out.println("THREE-MONTH DELIVERY REPORT");
        System.out.println("----------------------------");
        System.out.printf("%-12s", "YEAR");
        for (String m : months) {
            System.out.printf("%-8s", m);
        }
        System.out.println();

        // Loop through the 2D array to print data and calculate stats
        for (int i = 0; i < deliveries.length; i++) {
            System.out.printf("%-12s", "Deliveries " + years[i]);
            for (int j = 0; j < deliveries[i].length; j++) {
                System.out.printf("%-8d", deliveries[i][j]);
                
                total += deliveries[i][j];
                if (deliveries[i][j] > max) max = deliveries[i][j];
                if (deliveries[i][j] < min) min = deliveries[i][j];
            }
            System.out.println();
        }

        // Display statistics
        System.out.println("\nDELIVERIES STATISTICS");
        System.out.println("----------------------");
        System.out.println("Total Deliveries: " + total);
        System.out.println("Maximum Deliveries: " + max);
        System.out.println("Minimum Deliveries: " + min);
    }
}