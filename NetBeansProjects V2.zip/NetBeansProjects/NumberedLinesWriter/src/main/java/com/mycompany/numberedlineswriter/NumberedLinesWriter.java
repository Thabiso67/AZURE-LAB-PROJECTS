/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numberedlineswriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class NumberedLinesWriter {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String fileName = "text.txt";
        
        System.out.println("Enter text to write with line numbers (type 'exit' to finish):");
        
        try (FileWriter writer = new FileWriter(fileName)) {
            int lineNumber = 1;
            while (true) {
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("exit")) {
                    break;
                }
                writer.write("Line " + lineNumber + ": " + input + System.lineSeparator());
                lineNumber++;
            }
                System.out.println("Line written with numbers to 'text.txt'.");
            } catch (IOException e) {
                System.out.println("Error writing to file.");
                e.printStackTrace();
                    
            }
            scanner.close();
        }
    }