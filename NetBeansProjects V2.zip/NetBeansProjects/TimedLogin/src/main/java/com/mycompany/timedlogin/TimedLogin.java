/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.timedlogin;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class TimedLogin {

    public static void main(String[] args) throws InterruptedException {
        String user = JOptionPane.showInputDialog("Enter username:");
        String pass = JOptionPane.showInputDialog("Enter password:");
        
        JOptionPane.showMessageDialog(null, "Verifying, please wait...");
        Thread.sleep(2000); // simulate loading
        
        if (user.equals("admin") && pass.equals("Admin@123")) {
            JOptionPane.showMessageDialog(null, "Login successfull");
        }else{
            JOptionPane.showMessageDialog(null, "Login failed");
        }
    }
}
