/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.filedemo;

/**
 *
 * @author lab_services_student
 */

import java.io.*;

public class FileDemo {


public static void main(String[] args) {
SequentialWrite(); 

}
public static void SequentialWrite() {
BufferedWriter writer = null;

        
    try {
               writer = new BufferedWriter(new FileWriter("students.txt"));
               
               writer.write("John Smith, 85.5, Computer Science");
               writer.newLine();
               
               writer.write("Sarah Williams, 50, Mathematics");
               writer.newLine();
               
               writer.write("David Lee, 99, Business");
               writer.newLine();
               
               
               writer.close();
               
               System.out.println("Successfully wrote to file sequential");
               
       } 
        catch (IOException e) {
        System.out.println("Error writing to file: " +e.getMessage());
        }finally{
           try {
            writer.close();
            
            
         }catch (IOException e) {
          System.out.println("Error writing to file: " +e.getMessage());
     }
                 
        
    }
           
}


   public static void SequentialNeed() {
   
       
   BufferedReader reader = null;
   try
       
   {
       reader = new BufferedReader (new FileReader("student.txt"));
       
       String line;
       int lineNumber = 1;
       
       while ( line = reader.readLine() != null) {
           System.out.println("Line " + lineNumber + ": " +line);
           
           String []  lineItems = line.split(",");
           String name, qualification;
           int grade;
           if (lineItem.length == 3){
               name = lineItem[0];
               grade = Integer.parseInt(lineItems[1].trim ());
               qualification = lineItems[2];
           }
           System.out.println("Error writing to file: " + name);
           System.out.println("Error writing to file: " + grade);    
           System.out.println("Error writing to file: " + qualification);
           
           lineNumber++;
           
       }
       }
   } catch (IOException e) {
          System.out.println("Error writing to file: " +e.getMessage());
   
    }
   public static void RandomAccessPrice() {
       
       try{
           
           
       RandomAccessFile raf = null
       try {
           
       }
       raf.writeInt(101);
       raf.writeInt("Test 1");
       raf.writeInt(35.0);
       System.out.println("Successful write - student number : 103 name : Test,");
           
       raf.writeInt(101);
       raf.writeInt("Test 2");
       raf.writeInt(35.0);
       System.out.println("Successful write - student number : 103 name : Test,");
           
       raf.writeInt(101);
       raf.writeInt("Test 3");
       raf.writeInt(35.0);
       System.out.println("Successful write - student number : 103 name : Test,");
           
       }
       catch (IOException e){
       System.out.println(e.getMessage());
   }
   
       }
   }