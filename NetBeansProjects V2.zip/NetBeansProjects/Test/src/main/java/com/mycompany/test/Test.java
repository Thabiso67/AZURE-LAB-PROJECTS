/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.test;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class Test {
    
    private static final String [] Cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
    
    private static final String [] Vehicle_Types = {"Car", "Motorbike"};

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        
        int [][] accidents = new int[Cities.length][Vehicle_Types.length];
        
        System.out.println("Plese enter non-negative vehicle incident numbers");
        
        for (int city = 0; city < Cities.length; city ++) {
            
            for (int v = 0; v < Vehicle_Types.length; v++) {
                
                accidents[city] [v] = readNonNegativeInt(sc, "Enter number of" +
                        Vehicle_Types[v] + "accidents" + Cities[city]);
                }
        }
        
        
    
     int [] cityTotals = new int[Cities.length];
     
     for ( int city = 0; city < Cities.length; city ++ ) {
    int cityTotal = 0;
    for ( int v = 0; v < Vehicle_Types.length; v ++) {
        cityTotal += accidents[city][v];
    
}
         cityTotals[city] = cityTotal;
     
     
}
     
        int maxValue = 0;
        int maxValueIndex = 0;
        for (int i = 0; i < cityTotals.length; i ++ ) {
        if (maxValue < cityTotals[i] ){
            maxValue = cityTotals[i];
            maxValueIndex = 1;
        }
        }
        
        
        String cityWHighestIncident = Cities[maxValueIndex]; 
        
        sc.close();
    }
    
    
    
    
    
    
    
    
    
    
    
    //Get an input from user
private static int readNonNegativeInt(Scanner sc, String prompt) {
    System.out.println(prompt);
    int val = 0;
    if ( sc.hasNext()){
    val = sc.nextInt();
    return val;
 } else {
    System.out.println("Please enter a number");
    val = sc.nextInt();
}
  return val;  
}

private static void printReport (int [][] accidents, int cityTotals, String highCity ) {
    
    //
    //System.out.printf("@-15", "%10s", "@12s", "City", "Car", "Motorbike");
    
    for ( int city = 0; city < accidents.length; city ++) {
        for ( int v = 0; v < accidents[0].length; v ++ ) {
        

          System.out.print(accidents[city][v]  + ",");
       
    }
}
    for ( int city = 0; city < cityTotals.length; city ++) {
        System.out.println("The total for " + Cities[city]+ ":" +cityTotals);
    }
    
    System.out.println("The city with the highest amount of incidents is:" +highCity);
}
}