/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog6112examq2;

/**
 *
 * @author lab_services_student
 */
public class PROG6112ExamQ2 {

    public static void main(String[] args) {
 
    }
}
