/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dictionaryapp;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class DictionaryApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, String> dictionary = new HashMap<>();
        
        System.out.println("Welcome to the dictionary App");
        
        while (true) {
            System.out.print("\nEnter a word (or type 'exit' to finish):");
            String word = scanner.nextLine().trim();
            
            if (word.equalsIgnoreCase("exit")) {
                break;
                
             }
              
             if (word.isEmpty()) {
                System.out.println("Word cannot be empty.");
                continue;
                
             }
             
            System.out.print("Enter the defintion for \"" + word + "\": ");
            String definition = scanner.nextLine().trim();
            
            if (definition.isEmpty()) {
                System.out.println("Definition cannot be empty.");
                continue;
                
            }
            dictionary.put(word, definition);
            System.out.println("Entry added:");
            
            //Print the dictionary
            System.out.println("\n Your Dictionary");
            if (dictionary.isEmpty()) {
                System.out.println("No entries found.");
            }else{
                for (Map.Entry<String, String> entry : dictionary.entrySet()) {
                    System.out.println(entry.getKey() + ": " + entry.getValue());
                }
            }
            
            scanner.close();
            
            }
        }
    }
}